// supabase/functions/scanner-ler-rotulo/index.ts
// Lê a foto do rótulo de um produto e devolve uma SUGESTÃO de ficha (a equipe sempre confere antes de salvar).
// Só NUTRICIONISTA/ADMINISTRADOR. Só aceita fotos do bucket público "scanner" deste projeto.
//
// Deploy:   supabase functions deploy scanner-ler-rotulo
// Segredo:  supabase secrets set ANTHROPIC_API_KEY=sk-ant-...        (obrigatório)
//           supabase secrets set ANTHROPIC_MODEL=claude-haiku-5-5     (opcional; padrão abaixo)
import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
const json = (corpo: unknown, status = 200) =>
  new Response(JSON.stringify(corpo), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

const PROMPT = `Você lê a foto do rótulo de um alimento embalado (Brasil) e extrai dados para uma ficha.
Responda SOMENTE com um objeto JSON, sem texto antes ou depois, com estas chaves:
- "acucar": gramas de açúcares (ou "açúcares totais") a cada 100 g ou 100 ml, número ou null
- "sal": gramas de sal a cada 100 g/ml. Se o rótulo traz só SÓDIO (mg), converta: sal(g) = sódio(mg) x 2,5 / 1000. Número ou null
- "gorduraSat": gramas de gorduras saturadas a cada 100 g/ml, número ou null
- "fibra": gramas de fibra alimentar a cada 100 g/ml, número ou null
- "proteina": gramas de proteínas a cada 100 g/ml, número ou null
- "aditivos": quantos ingredientes da lista são aditivos (corante, conservante, aromatizante, estabilizante, espessante, emulsificante, acidulante, antioxidante, realçador de sabor, edulcorante, ou código INS/E). Inteiro ou null se não há lista de ingredientes legível
- "ingredientes": a lista de ingredientes como está no rótulo, na mesma ordem, ou null
Regras: use apenas a coluna "100 g" ou "100 ml"; se a tabela só tiver a coluna "por porção", devolva null nos nutrientes (não calcule). Não invente: se não está legível, null. Ignore calorias. Use ponto como separador decimal.`;

const NUM = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= 100 ? Math.round(v * 100) / 100 : null);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ erro: 'Método não permitido.' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
  const chave = Deno.env.get('ANTHROPIC_API_KEY');
  if (!chave) return json({ erro: 'Leitura automática não configurada (falta ANTHROPIC_API_KEY).' }, 503);

  // 1. só a equipe: o papel é conferido no banco com o token de quem chamou
  const auth = req.headers.get('Authorization') ?? '';
  const cliente = createClient(supabaseUrl, anon, { global: { headers: { Authorization: auth } } });
  const { data: papel, error: erroPapel } = await cliente.rpc('papel_atual');
  if (erroPapel || !['NUTRICIONISTA', 'ADMINISTRADOR'].includes(String(papel ?? ''))) return json({ erro: 'Acesso negado.' }, 403);

  // 2. só fotos do nosso bucket (evita usar a função para ler qualquer endereço)
  let url = '';
  try { url = String((await req.json())?.url ?? ''); } catch { /* corpo inválido */ }
  // prefixo + sem '..', '?', '#' ou '%' (evita escapar do bucket por caminho relativo/codificado)
  if (!url.startsWith(`${supabaseUrl}/storage/v1/object/public/scanner/`) || /[?#%]|\.\./.test(url.slice(supabaseUrl.length)) || url.length > 500) {
    return json({ erro: 'Foto inválida.' }, 400);
  }

  // 3. leitura
  let resposta: Response;
  try {
    resposta = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': chave, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: Deno.env.get('ANTHROPIC_MODEL') ?? 'claude-haiku-5-5',
        max_tokens: 700,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'url', url } },
          { type: 'text', text: PROMPT },
        ] }],
      }),
    });
  } catch { return json({ erro: 'Não foi possível ler a foto agora.' }, 502); }
  if (!resposta.ok) return json({ erro: 'Não foi possível ler a foto agora.' }, 502);

  const texto: string = (await resposta.json())?.content?.find((c: any) => c.type === 'text')?.text ?? '';
  const trecho = texto.match(/\{[\s\S]*\}/)?.[0];
  if (!trecho) return json({ erro: 'Não consegui ler o rótulo nessa foto. Tente uma foto mais nítida.' }, 422);
  let bruto: any;
  try { bruto = JSON.parse(trecho); } catch { return json({ erro: 'Não consegui ler o rótulo nessa foto.' }, 422); }

  const aditivos = Number.isInteger(bruto?.aditivos) && bruto.aditivos >= 0 && bruto.aditivos <= 99 ? bruto.aditivos : null;
  const ingredientes = typeof bruto?.ingredientes === 'string' && bruto.ingredientes.trim() ? bruto.ingredientes.trim().slice(0, 600) : null;
  return json({ campos: {
    acucar: NUM(bruto?.acucar), sal: NUM(bruto?.sal), gorduraSat: NUM(bruto?.gorduraSat),
    fibra: NUM(bruto?.fibra), proteina: NUM(bruto?.proteina), aditivos, ingredientes,
  } });
});
