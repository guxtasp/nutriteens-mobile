import React, { useState } from 'react';
import { View, Pressable, StyleSheet, Platform, useWindowDimensions } from 'react-native';
import { colors } from '../../../shared/theme/colors';
import { typography } from '../../../shared/theme/typography';
import { AppText } from '../../../shared/ui/AppText';
import { AppButton } from '../../../shared/ui/AppButton';
import { BackButton } from '../../../shared/ui/BackButton';
import { LabeledInput } from '../../../shared/ui/LabeledInput';
import { PasswordInput } from '../../../shared/ui/PasswordInput';
import { Divider } from '../../../shared/ui/Divider';
import { MessageBanner } from '../../../shared/ui/MessageBanner';
import { useMessageBanner } from '../../../shared/hooks/useMessageBanner';
import { supabase } from '../../../lib/supabase';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useGoogleAuth } from '../hooks/useGoogleAuth';
import { mensagemErroLogin } from '../utils/loginErros';
import { acessoProfissionalDisponivel } from '../utils/acessoProfissional';

const LARGURA_DESKTOP = 760;

export default function LoginScreen({ navigation }: any) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { message, type, showMessage, clearMessage } = useMessageBanner();
  const { carregandoGoogle, continuarComGoogle } = useGoogleAuth(showMessage);
  const { width } = useWindowDimensions();
  const ehDesktop = Platform.OS === 'web' && width >= LARGURA_DESKTOP;

  async function handleLogin() {
    if (!email || !password) {
      showMessage('Preencha email e senha', 'error');
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);

    if (error) {
      // Mesma mensagem para qualquer recusa de login (senha errada, conta inexistente, e-mail
      // não confirmado...): mensagens diferentes revelariam quais e-mails têm conta (RF005).
      // Só falha de conexão/servidor tem texto próprio, pois não diz nada sobre a conta.
      showMessage(mensagemErroLogin(error), 'error');
      return;
    }

    showMessage('Você entrou no app!', 'success');
  }

  return (
    <View style={[styles.outer, ehDesktop && styles.outerDesktop]}>
    <View style={[styles.container, ehDesktop && styles.containerDesktop]}>
      <BackButton onPress={() => navigation.goBack()} style={styles.BackButton} />

      <AppText style={styles.title}>Olha você! Seja bem-vindo(a) novamente ;)</AppText>

      <AppText style={styles.subtitle}>
        Faça login ou{' '}
        <AppText style={styles.link} onPress={() => navigation.navigate('AppPresentation')}>
          crie uma conta aqui
        </AppText>
      </AppText>

      {/* só no computador (ver acessoProfissional.ts) */}
      {acessoProfissionalDisponivel(Platform.OS, width) && (
        <Pressable onPress={() => navigation.navigate('LoginProfissional')} accessibilityRole="link" style={styles.linkProfissional}>
          <AppText style={styles.link}>Sou nutricionista ou administrador</AppText>
        </Pressable>
      )}

      <LabeledInput
        label="Email"
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <PasswordInput label="Senha" value={password} onChangeText={setPassword} />

      <Pressable onPress={() => navigation.navigate('EsqueciSenha')}>
        <AppText style={styles.forgotPassword}>Esqueci minha senha</AppText>
      </Pressable>

      <Divider />

      <AppButton
        label={carregandoGoogle ? 'ABRINDO O GOOGLE...' : 'G  ENTRAR COM O GOOGLE'}
        backgroundColor={colors.white}
        fullWidth
        borderWidth={0.5}
        outlineColor="#000000"
        textColor={colors.primaryDark}
        shadowColor={colors.primaryDark}
        onPress={continuarComGoogle}
      />

      <View style={styles.spacer} />
      <View style={styles.messageContainer}>
        <MessageBanner message={message} type={type} onClose={clearMessage} />
        <AppButton
          label={loading ? 'ENTRANDO...' : 'VAMOS LÁ'}
          backgroundColor={colors.primaryDark}
          textColor={colors.white}
          shadowColor="#123024"
          onPress={handleLogin}
        />
      </View>

    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // No mobile o form ocupa a tela toda; no desktop web ele vira um card
  // centralizado (senão fica esticado até a borda de uma janela larga).
  outer: {
    flex: 1,
    backgroundColor: colors.white,
  },
  outerDesktop: {
    backgroundColor: '#F5F6F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container: { 
    flex: 1, 
    backgroundColor: colors.white, 
    paddingHorizontal: 24, 
    paddingTop: 60,
    paddingBottom: 70, // espaço pro botão de navegação do Android
  },
  containerDesktop: {
    flex: undefined,
    width: '100%',
    maxWidth: 420,
    paddingTop: 40,
    paddingBottom: 40,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E5E7E5',
    // @ts-ignore — boxShadow só existe no web (react-native-web aceita)
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.06)',
  },
  BackButton: {
    marginBottom: 32,
  },
  title: { 
    fontFamily: typography.bold, 
    fontSize: 24, 
    color: colors.primaryDark, 
    lineHeight: 32, 
    marginBottom: 8 
  },
  subtitle: { 
    fontFamily: typography.regular, 
    fontSize: 16, 
    color: colors.primaryDark, 
    marginBottom: 24 
  },
  link: { 
    fontFamily: typography.bold, 
    textDecorationLine: 'underline' 
  },
  linkProfissional: {
    alignSelf: 'flex-start',
    minHeight: 44,
    justifyContent: 'center',
    marginTop: -16,
    marginBottom: 8,
  },
  forgotPassword: { 
    fontFamily: typography.regular, 
    color: colors.primaryDark, 
    textAlign: 'center', 
    textDecorationLine: 'underline', 
    marginTop: 10,
    marginBottom: 24 
  },
  messageContainer: { 
    marginTop: -40,
    flex:1,
    gap: 12, 
  },
  spacer: { 
    height: 60 
  },
});