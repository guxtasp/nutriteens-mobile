// src/features/admin/screens/UsuariosScreen.tsx
// Lista de usuários do Admin: dados reais (via função do banco), busca, filtro por papel,
// ordenação e "carregar mais". Toque abre os detalhes. Tabela no desktop, cartões no celular.
import React from 'react';
import { Pressable, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PainelLayout } from '../../../shared/painel/PainelLayout';
import { IntroSecao } from '../../../shared/painel/components/IntroSecao';
import { AjudaInfo } from '../../../shared/painel/components/AjudaInfo';
import { EstadoCarregando, EstadoErro } from '../../../shared/painel/components/EstadosPainel';
import {
  CampoBusca, ChipsFiltro, RodapeLista, Selo, VazioPainel,
} from '../../../shared/painel/components/ControlesLista';
import { useListaPaginada } from '../../../shared/painel/hooks/useListaPaginada';
import { useModoPainel } from '../../../shared/painel/hooks/useModoPainel';
import { dataCurta, ultimoAcessoTexto } from '../../../shared/painel/formatadores';
import { AppText } from '../../../shared/ui/AppText';
import { typography } from '../../../shared/theme/typography';
import type { TemaPainel } from '../../../shared/painel/tema/paletas';
import { useEstilos, useTemaPainel } from '../../../shared/painel/tema/TemaPainelContext';
import { ADMIN_PAINEL } from '../navigation/adminMenu';
import { Papel, UsuarioAdmin, labelPapel, listarUsuarios } from '../services/usuariosAdminService';

const FILTROS = [
  { chave: 'TODOS', label: 'Todos' },
  { chave: 'ADOLESCENTE', label: 'Adolescentes' },
  { chave: 'NUTRICIONISTA', label: 'Nutricionistas' },
  { chave: 'ADMINISTRADOR', label: 'Administradores' },
];
const ORDENS = [
  { chave: 'recentes', label: 'Mais recentes' },
  { chave: 'nome', label: 'Nome/apelido (A–Z)' },
  { chave: 'acesso', label: 'Último acesso' },
];

// LGPD (D4): adolescente aparece por apelido e código; o nome real é só da nutricionista.
function nomeExibido(u: UsuarioAdmin) {
  if (u.papel === 'ADOLESCENTE') return u.apelido?.trim() || u.codigoParticipante || 'Sem apelido';
  return u.nome?.trim() || u.apelido?.trim() || 'Sem nome';
}
function SeloStatus({ u }: { u: UsuarioAdmin }) {
  return <Selo texto={u.ativo ? 'Ativo' : 'Inativo'} tom={u.ativo ? 'ok' : 'neutro'} />;
}

export default function UsuariosScreen() {
  const styles = useEstilos(criarEstilos);
  const navigation = useNavigation<any>();
  const { largura } = useModoPainel();
  const lista = useListaPaginada<UsuarioAdmin>(
    (p) => listarUsuarios({ busca: p.busca, papel: (p.filtro as Papel) || null, ordem: p.ordem, limite: p.limite, offset: p.offset }),
    { ordemInicial: 'recentes' }
  );
  const abrir = (u: UsuarioAdmin) => navigation.navigate('UsuarioDetalhe', { id: u.id });
  // Tabela de 6 colunas só quando cabe (~900px de janela, já descontado o menu);
  // abaixo disso, cartões empilhados leem melhor que colunas espremidas.
  const tabela = largura >= 900;

  return (
    <PainelLayout config={ADMIN_PAINEL} titulo="Usuários" subtitulo="Todas as contas do NutriTeens">
      <IntroSecao
        chave="admin_usuarios"
        titulo="Gerenciar usuários"
        linhas={[
          'Aqui ficam as contas de adolescentes, nutricionistas e administradores. Por privacidade (LGPD), adolescentes aparecem por apelido e código. Busque por apelido, código do participante ou nome da equipe.',
          'Ativo = usou o aplicativo nos últimos 30 dias. Toque em um usuário para ver os detalhes.',
          'Por privacidade, esta área não mostra dados de saúde nem de alimentação dos adolescentes.',
        ]}
      />

      <View style={styles.controles}>
        <CampoBusca valor={lista.busca} onChange={lista.setBusca} placeholder="Buscar por apelido, código ou equipe" />
        <ChipsFiltro opcoes={FILTROS} valor={lista.filtro ?? 'TODOS'} onChange={(c) => lista.setFiltro(c === 'TODOS' ? null : c)} rotulo="Filtrar" />
        <View style={styles.linhaOrdem}>
          <AppText style={styles.ordemRotulo}>Ordenar por</AppText>
          <ChipsFiltro opcoes={ORDENS} valor={lista.ordem} onChange={lista.setOrdem} rotulo="Ordenar por" />
        </View>
      </View>

      {lista.carregando && lista.itens.length === 0 ? (
        <EstadoCarregando />
      ) : lista.erro && lista.itens.length === 0 ? (
        <EstadoErro mensagem={lista.erro} onTentar={lista.recarregar} />
      ) : lista.itens.length === 0 ? (
        <VazioPainel
          titulo="Nenhum usuário encontrado"
          texto={lista.busca || lista.filtro ? 'Tente outra busca ou volte para "Todos".' : 'Ainda não há usuários cadastrados.'}
        />
      ) : (
        <View style={{ gap: 10 }}>
          {tabela && (
            <View style={[styles.linha, styles.cabecalho]}>
              <AppText style={[styles.th, styles.cNome]}>Nome</AppText>
              <AppText style={[styles.th, styles.cPapel]}>Papel</AppText>
              <View style={[styles.cStatus, { flexDirection: 'row', alignItems: 'center', gap: 4 }]}>
                <AppText style={styles.th}>Status</AppText>
                <AjudaInfo titulo="Status" texto="Ativo: usou o aplicativo nos últimos 30 dias. Inativo: sem uso nesse período." />
              </View>
              <AppText style={[styles.th, styles.cCodigo]}>Código</AppText>
              <AppText style={[styles.th, styles.cData]}>Cadastro</AppText>
              <AppText style={[styles.th, styles.cData]}>Último acesso</AppText>
            </View>
          )}
          {lista.itens.map((u) =>
            tabela ? (
              <Pressable key={u.id} onPress={() => abrir(u)} accessibilityRole="button" accessibilityLabel={`Abrir detalhes de ${nomeExibido(u)}`} style={[styles.linha, styles.linhaDado]}>
                <View style={styles.cNome}>
                  <AppText style={styles.nome} numberOfLines={1}>{nomeExibido(u)}</AppText>
                  {!!u.apelido && u.papel !== 'ADOLESCENTE' && u.nome !== u.apelido && <AppText style={styles.sub} numberOfLines={1}>@{u.apelido}</AppText>}
                </View>
                <View style={styles.cPapel}><Selo texto={labelPapel(u.papel)} tom="info" /></View>
                <View style={styles.cStatus}><SeloStatus u={u} /></View>
                <AppText style={[styles.td, styles.cCodigo]} numberOfLines={1}>{u.codigoParticipante ?? '—'}</AppText>
                <AppText style={[styles.td, styles.cData]}>{dataCurta(u.criadoEm)}</AppText>
                <AppText style={[styles.td, styles.cData]}>{ultimoAcessoTexto(u.ultimoAcesso)}</AppText>
              </Pressable>
            ) : (
              <Pressable key={u.id} onPress={() => abrir(u)} accessibilityRole="button" accessibilityLabel={`Abrir detalhes de ${nomeExibido(u)}`} style={styles.card}>
                <View style={styles.cardTopo}>
                  <AppText style={[styles.nome, { flexShrink: 1 }]} numberOfLines={2}>{nomeExibido(u)}</AppText>
                  <SeloStatus u={u} />
                </View>
                <View style={styles.cardSelos}>
                  <Selo texto={labelPapel(u.papel)} tom="info" />
                  {!!u.codigoParticipante && <Selo texto={`Código ${u.codigoParticipante}`} />}
                </View>
                <AppText style={styles.sub}>
                  Cadastro {dataCurta(u.criadoEm)} · {ultimoAcessoTexto(u.ultimoAcesso)}
                </AppText>
              </Pressable>
            )
          )}
          <RodapeLista mostrados={lista.itens.length} total={lista.total} temMais={lista.temMais} carregando={lista.carregandoMais} onMais={lista.carregarMais} />
          {!!lista.erro && <AppText style={styles.erro}>{lista.erro}</AppText>}
        </View>
      )}
    </PainelLayout>
  );
}

const criarEstilos = (t: TemaPainel) => ({
  controles: { gap: 12, marginBottom: 12 },
  linhaOrdem: { gap: 6 },
  ordemRotulo: { fontFamily: typography.medium, fontSize: 12, color: t.textoSuave },
  linha: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cabecalho: { paddingHorizontal: 14 },
  linhaDado: {
    backgroundColor: t.card, borderRadius: 14, borderWidth: t.borda, borderColor: t.cardBorda,
    paddingHorizontal: 14, paddingVertical: 12, minHeight: 56,
  },
  th: { fontFamily: typography.bold, fontSize: 11, color: t.textoSuave, textTransform: 'uppercase' },
  td: { fontFamily: typography.regular, fontSize: 13, color: t.textoCorpo },
  cNome: { flex: 3, minWidth: 0 },
  cPapel: { flex: 2, minWidth: 0 },
  cStatus: { flex: 1.4, minWidth: 0 },
  cCodigo: { flex: 1.6, minWidth: 0 },
  cData: { flex: 1.6, minWidth: 0 },
  nome: { fontFamily: typography.bold, fontSize: 14, color: t.texto },
  sub: { fontFamily: typography.regular, fontSize: 12, color: t.textoSuave },
  card: { backgroundColor: t.card, borderRadius: t.cardRaio, borderWidth: t.borda, borderColor: t.cardBorda, padding: 14, gap: 8, minHeight: 48 },
  cardTopo: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 },
  cardSelos: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  erro: { fontFamily: typography.regular, fontSize: 12, color: t.erro, textAlign: 'center' },
}) as const;
