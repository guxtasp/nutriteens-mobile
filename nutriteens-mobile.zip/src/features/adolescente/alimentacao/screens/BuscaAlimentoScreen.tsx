import React, { useState, useEffect, useRef, useCallback } from 'react';
import { View, StyleSheet, Pressable, TextInput, FlatList, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { AdolescenteStackParamList } from '../../../../navigation/AdolescenteNavigator';
import { AppText } from '../../../../shared/ui/AppText';
import { BackButton } from '../../../../shared/ui/BackButton';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import {
  buscarAlimentos,
  listarAlimentosIniciais,
  listarMeusAlimentos,
  listarPratos,
  buscarPratos,
  Alimento,
} from '../services/alimentacaoService';
import { listarReceitas, buscarReceitas, ReceitaComAlimento } from '../services/receitasService';
import { useAlimentacao } from '../contexts/AlimentacaoContext';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import CarrinhoAlimentosBar from '../components/CarrinhoAlimentarBar';
import CarrinhoAlimentosSheet from '../components/CarrinhoAlimentarSheet';
import ReceitaDetalheSheet from '../components/ReceitaDetalheSheet';
import { EnviarReceitaSheet } from '../../social/components/EnviarReceitaSheet';
import { FiltroChips } from '../../../../shared/ui/FiltroChips';
import { buscarGruposAlimentaresInfo } from '../services/gruposAlimentaresService';
import {
  FILTRO_ALIMENTO_VAZIO,
  FILTRO_RECEITA_VAZIO,
  OPCOES_TEMPO_MIN,
  filtrarAlimentos,
  filtrarReceitas,
  filtroAlimentoAtivo,
  filtroReceitaAtivo,
  gruposDisponiveis,
  rotuloDoGrupo,
  type Dificuldade,
  type FiltroAlimento,
  type FiltroReceita,
} from '../utils/filtrosAlimento';
import type { ClassificacaoNova } from '../utils/regraFeedbackRefeicao';

type NavigationProp = NativeStackNavigationProp<AdolescenteStackParamList, 'BuscaAlimento'>;
type RouteProps = RouteProp<AdolescenteStackParamList, 'BuscaAlimento'>;

type Aba = 'alimento' | 'prato' | 'receita';

const OPCOES_NOVA = [
  { chave: 'IN_NATURA', label: 'In natura' },
  { chave: 'INGREDIENTE_CULINARIO', label: 'Culinário' },
  { chave: 'PROCESSADO', label: 'Processado' },
  { chave: 'ULTRAPROCESSADO', label: 'Ultraprocessado' },
];
const OPCOES_DIFICULDADE = [
  { chave: 'FACIL', label: 'Fácil' },
  { chave: 'MEDIO', label: 'Médio' },
  { chave: 'DIFICIL', label: 'Difícil' },
];
const OPCOES_TEMPO = OPCOES_TEMPO_MIN.map((m) => ({ chave: String(m), label: `Até ${m} min` }));

function rotuloClassificacao(c: Alimento['classificacao_nova']) {
  switch (c) {
    case 'IN_NATURA': return 'IN NATURA';
    case 'INGREDIENTE_CULINARIO': return 'INGREDIENTE CULINÁRIO';
    case 'PROCESSADO': return 'PROCESSADO';
    case 'ULTRAPROCESSADO': return 'ULTRAPROCESSADO';
    default: return '';
  }
}

export default function BuscaAlimentoScreen() {
  const navigation = useNavigation<NavigationProp>();
  const { params } = useRoute<RouteProps>();
  const { userId } = useAuth();
  const { carrinho, adicionarAoCarrinho, incrementarItem, decrementarItem, removerDoCarrinho, registrarCarrinho, enviando } = useAlimentacao();

  const [aba, setAba] = useState<Aba>('alimento');
  const [termo, setTermo] = useState('');
  const [resultados, setResultados] = useState<Alimento[]>([]);
  const [receitasResultados, setReceitasResultados] = useState<ReceitaComAlimento[]>([]);
  const [meusAlimentos, setMeusAlimentos] = useState<Alimento[]>([]);
  const [buscando, setBuscando] = useState(false);
  const [sheetCarrinho, setSheetCarrinho] = useState(false);
  const [receitaAberta, setReceitaAberta] = useState<ReceitaComAlimento | null>(null);
  const [filtrosAbertos, setFiltrosAbertos] = useState(false);
  const [filtroAlimento, setFiltroAlimento] = useState<FiltroAlimento>(FILTRO_ALIMENTO_VAZIO);
  const [filtroReceita, setFiltroReceita] = useState<FiltroReceita>(FILTRO_RECEITA_VAZIO);
  const [titulosGrupos, setTitulosGrupos] = useState<Record<string, string>>({});
  const [receitaParaEnviar, setReceitaParaEnviar] = useState<{ id: string; titulo: string } | null>(null);

  const ultimoIdProcessado = useRef<string | null>(null);

  // nomes amigáveis dos grupos (tabela grupos_alimentares_info); se falhar, o rótulo é gerado do código
  useEffect(() => {
    buscarGruposAlimentaresInfo()
      .then((info) => setTitulosGrupos(Object.fromEntries(Object.values(info).map((g) => [g.grupo, g.titulo_amigavel]))))
      .catch(() => undefined);
  }, []);

  // grupo de "Prato" não existe em "Alimento" e vice-versa: ao trocar de aba, limpa para não esconder resultados sem querer
  useEffect(() => {
    setFiltroAlimento(FILTRO_ALIMENTO_VAZIO);
  }, [aba]);

  // FIX: Adiciona item recém-criado ao carrinho de forma segura e limpa
  useEffect(() => {
    const recemCriado = params?.alimentoRecemCriado;
    if (recemCriado && recemCriado.id !== ultimoIdProcessado.current) {
      ultimoIdProcessado.current = recemCriado.id;
      adicionarAoCarrinho(recemCriado);
      setSheetCarrinho(true);
    }
  }, [params?.alimentoRecemCriado, adicionarAoCarrinho]);

  // Carrega "meus alimentos"
  useEffect(() => {
    if (!userId) return;
    listarMeusAlimentos(userId)
      .then(setMeusAlimentos)
      .catch(() => setMeusAlimentos([]));
  }, [userId, params?.alimentoRecemCriado]);

  // Busca e listagem unificada com debounce otimizado
  useEffect(() => {
    if (!userId) return;
    setBuscando(true);
    
    const timeout = setTimeout(async () => {
      try {
        const termoLimpo = termo.trim();
        if (aba === 'alimento') {
          const dados = termoLimpo ? await buscarAlimentos(termoLimpo, userId) : await listarAlimentosIniciais(userId);
          setResultados(dados);
        } else if (aba === 'prato') {
          const dados = termoLimpo ? await buscarPratos(termoLimpo, userId) : await listarPratos(userId);
          setResultados(dados);
        } else if (aba === 'receita') {
          const dados = termoLimpo ? await buscarReceitas(termoLimpo, userId) : await listarReceitas(userId);
          setReceitasResultados(dados);
        }
      } catch (erro) {
        console.error('Erro ao carregar dados:', erro);
      } finally {
        setBuscando(false);
      }
    }, termo.trim() ? 350 : 0);

    return () => clearTimeout(timeout);
  }, [termo, aba, userId]);

  function irParaCadastro() {
    navigation.navigate('NovoAlimentoOrigem', { tipo: params.tipo, nomeRefeicao: params.nomeRefeicao });
  }

  async function handleRegistrar() {
    try {
      const resultado = await registrarCarrinho(params.tipo);
      if (!resultado) return;
      setSheetCarrinho(false);
      if (resultado.offline) {
        Alert.alert(
          'Refeição guardada! 📱',
          'Você está sem internet, então guardamos o registro no celular. Ele sobe sozinho quando a conexão voltar e o retorno da refeição aparece depois.',
          [{ text: 'Ok', onPress: () => navigation.navigate('Alimentacao') }]
        );
        return;
      }
      navigation.navigate('FeedbackRefeicao', {
        tipo: params.tipo,
        nomeRefeicao: params.nomeRefeicao,
        nivelQualidade: resultado.nivelQualidade,
        intensidade: resultado.intensidade,
        processamento: resultado.processamento,
        nutricional: resultado.nutricional,
        melhoria: resultado.melhoria,
        missao: resultado.missao,
        troca: resultado.troca,
      });
    } catch (erro) {
      console.error('Erro ao registrar refeição:', erro);
      Alert.alert('Não deu pra registrar', 'Algo deu errado ao salvar essa refeição. Tenta de novo em instantes.');
    }
  }

  const adicionarReceitaAoCarrinho = useCallback((receita: ReceitaComAlimento) => {
    adicionarAoCarrinho(receita.alimento_resultante);
    setReceitaAberta(null);
    setSheetCarrinho(true);
  }, [adicionarAoCarrinho]);

  const resultadosFiltrados = filtrarAlimentos(resultados, filtroAlimento);
  const meusFiltrados = filtrarAlimentos(meusAlimentos, filtroAlimento);
  const receitasFiltradas = filtrarReceitas(receitasResultados, filtroReceita);
  const opcoesGrupo = gruposDisponiveis(aba === 'alimento' ? [...meusAlimentos, ...resultados] : resultados).map((g) => ({
    chave: g,
    label: rotuloDoGrupo(g, titulosGrupos),
  }));
  const filtroAtivo = aba === 'receita' ? filtroReceitaAtivo(filtroReceita) : filtroAlimentoAtivo(filtroAlimento);

  function limparFiltros() {
    setFiltroAlimento(FILTRO_ALIMENTO_VAZIO);
    setFiltroReceita(FILTRO_RECEITA_VAZIO);
  }

  const mostrarSecaoMeusAlimentos = aba === 'alimento' && !termo.trim() && meusFiltrados.length > 0;

  // Renderizadores otimizados para FlatList evitando re-criação de funções
  const renderItemAlimentoPrato = useCallback(({ item }: { item: Alimento }) => (
    <Pressable style={styles.itemCard} onPress={() => adicionarAoCarrinho(item)}>
      <View style={{ flex: 1 }}>
        <AppText style={styles.itemNome} numberOfLines={2}>{item.nome}</AppText>
        <AppText style={styles.itemClassificacao}>{rotuloClassificacao(item.classificacao_nova)}</AppText>
      </View>
      <View style={styles.botaoAdicionarPequeno}>
        <Ionicons name="add" size={16} color="#fff" />
      </View>
    </Pressable>
  ), [adicionarAoCarrinho]);

  const renderItemReceita = useCallback(({ item }: { item: ReceitaComAlimento }) => (
    <Pressable style={styles.itemCard} onPress={() => setReceitaAberta(item)}>
      <View style={{ flex: 1 }}>
        <AppText style={styles.itemNome} numberOfLines={2}>{item.titulo}</AppText>
        <AppText style={styles.itemClassificacao}>
          {item.tempo_preparo_min ? `${item.tempo_preparo_min} min • ` : ''}
          {item.porcoes} porção(ões)
        </AppText>
      </View>
      <Ionicons name="chevron-forward" size={18} color="#8BC34A" />
    </Pressable>
  ), []);

  return (
    <SafeAreaView style={styles.tela}>
      <View style={styles.cabecalho}>
        <BackButton onPress={() => navigation.goBack()} />
        <View style={styles.tituloBloco}>
          <AppText style={styles.titulo}>{params.nomeRefeicao}</AppText>
          <AppText style={styles.subtitulo}>Diga pra gente: o que comeu agora?</AppText>
        </View>
      </View>

      <View style={styles.corpo}>
        <View style={styles.buscaLinha}>
          <View style={styles.buscaCaixa}>
            <Ionicons name="search" size={18} color="#7A8B94" />
            <TextInput
              style={styles.buscaInput}
              placeholder={aba === 'receita' ? 'Pesquisar receita...' : 'Pesquisar alimento...'}
              placeholderTextColor="#7A8B94"
              value={termo}
              onChangeText={setTermo}
            />
          </View>
          <Pressable style={styles.botaoInfo} accessibilityLabel="Informações">
            <Ionicons name="information" size={18} color="#fff" />
          </Pressable>
          <Pressable
            style={[styles.botaoInfo, filtrosAbertos && styles.botaoFiltroAberto]}
            onPress={() => setFiltrosAbertos((v) => !v)}
            accessibilityLabel={filtrosAbertos ? 'Esconder filtros' : 'Mostrar filtros'}
          >
            <Ionicons name="options" size={18} color="#fff" />
            {filtroAtivo && <View style={styles.pontoFiltro} />}
          </Pressable>
          {aba !== 'receita' && (
            <Pressable style={styles.botaoAdicionar} onPress={irParaCadastro} accessibilityLabel="Cadastrar novo alimento">
              <Ionicons name="add" size={20} color="#fff" />
            </Pressable>
          )}
        </View>

        <View style={styles.abasLinha}>
          <Pressable style={styles.aba} onPress={() => setAba('alimento')}>
            <View style={[styles.abaIcone, { backgroundColor: aba === 'alimento' ? colors.primaryDark : colors.primary }]}>
              <MaterialCommunityIcons name="fruit-grapes" size={60} color="#fff" />
            </View>
            <AppText style={aba === 'alimento' ? styles.abaTextoAtivo : styles.abaTexto}>Alimento</AppText>
          </Pressable>

          <Pressable style={styles.aba} onPress={() => setAba('prato')}>
            <View style={[styles.abaIcone, { backgroundColor: aba === 'prato' ? colors.primaryDark : colors.primary }]}>
              <MaterialCommunityIcons name="pot-steam" size={60} color="#fff" />
            </View>
            <AppText style={aba === 'prato' ? styles.abaTextoAtivo : styles.abaTexto}>Prato</AppText>
          </Pressable>

          <Pressable style={styles.aba} onPress={() => setAba('receita')}>
            <View style={[styles.abaIcone, { backgroundColor: aba === 'receita' ? colors.primaryDark : colors.primary }]}>
              <MaterialCommunityIcons name="mortar-pestle" size={60} color="#fff" />
            </View>
            <AppText style={aba === 'receita' ? styles.abaTextoAtivo : styles.abaTexto}>Receitas</AppText>
          </Pressable>
        </View>

        {filtrosAbertos && (
          <View style={styles.painelFiltros}>
            {aba === 'receita' ? (
              <>
                <FiltroChips
                  rotuloTodos="Qualquer dificuldade"
                  opcoes={OPCOES_DIFICULDADE}
                  valor={filtroReceita.dificuldade}
                  onChange={(c) => setFiltroReceita((f) => ({ ...f, dificuldade: c as Dificuldade | null }))}
                />
                <FiltroChips
                  rotuloTodos="Qualquer tempo"
                  opcoes={OPCOES_TEMPO}
                  valor={filtroReceita.tempoMaxMin === null ? null : String(filtroReceita.tempoMaxMin)}
                  onChange={(c) => setFiltroReceita((f) => ({ ...f, tempoMaxMin: c === null ? null : Number(c) }))}
                />
              </>
            ) : (
              <>
                <FiltroChips
                  rotuloTodos="Qualquer tipo"
                  opcoes={OPCOES_NOVA}
                  valor={filtroAlimento.nova}
                  onChange={(c) => setFiltroAlimento((f) => ({ ...f, nova: c as ClassificacaoNova | null }))}
                />
                {opcoesGrupo.length > 0 && (
                  <FiltroChips
                    rotuloTodos="Todos os grupos"
                    opcoes={opcoesGrupo}
                    valor={filtroAlimento.grupo}
                    onChange={(c) => setFiltroAlimento((f) => ({ ...f, grupo: c }))}
                  />
                )}
              </>
            )}
            {filtroAtivo && (
              <Pressable onPress={limparFiltros} style={styles.limparFiltros}>
                <AppText style={styles.limparFiltrosTexto}>Limpar filtros</AppText>
              </Pressable>
            )}
          </View>
        )}

        {buscando && <ActivityIndicator color="#8BC34A" style={{ marginTop: 20 }} />}

        {!buscando && aba !== 'receita' && (
          <FlatList
            data={resultadosFiltrados}
            keyExtractor={(item) => item.id}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
            contentContainerStyle={{ gap: 12, paddingTop: 4, paddingBottom: carrinho.length > 0 ? 100 : 20 }}
            ListHeaderComponent={
              mostrarSecaoMeusAlimentos ? (
                <View style={{ marginBottom: 12 }}>
                  <AppText style={styles.secaoLabel}>Cadastrados por você</AppText>
                  {meusFiltrados.map((item) => (
                    <Pressable key={`meu-${item.id}`} style={styles.itemCard} onPress={() => adicionarAoCarrinho(item)}>
                      <View style={{ flex: 1 }}>
                        <AppText style={styles.itemNome} numberOfLines={2}>
                          {item.nome}
                        </AppText>
                        <AppText style={styles.itemClassificacao}>
                          {rotuloClassificacao(item.classificacao_nova)}
                        </AppText>
                      </View>
                      <View style={styles.botaoAdicionarPequeno}>
                        <Ionicons name="add" size={16} color="#fff" />
                      </View>
                    </Pressable>
                  ))}
                  <AppText style={[styles.secaoLabel, { marginTop: 16 }]}>Opções</AppText>
                </View>
              ) : null
            }
            ListEmptyComponent={
              filtroAtivo && resultados.length > 0 ? (
                <AppText style={styles.vazioTexto}>Nada com esses filtros. Toque em "Limpar filtros" pra ver tudo.</AppText>
              ) : termo.trim().length > 0 ? (
                <AppText style={styles.vazioTexto}>
                  {aba === 'prato'
                    ? 'Nenhum prato encontrado.'
                    : 'Nenhum alimento encontrado. Toque no "+" pra cadastrar.'}
                </AppText>
              ) : null
            }
            renderItem={renderItemAlimentoPrato}
          />
        )}

        {!buscando && aba === 'receita' && (
          <FlatList
            data={receitasFiltradas}
            keyExtractor={(item) => item.id}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
            contentContainerStyle={{ gap: 12, paddingTop: 4, paddingBottom: carrinho.length > 0 ? 100 : 20 }}
            ListEmptyComponent={
              <AppText style={styles.vazioTexto}>
                {filtroAtivo && receitasResultados.length > 0
                  ? 'Nenhuma receita com esses filtros. Toque em "Limpar filtros" pra ver tudo.'
                  : 'Nenhuma receita encontrada.'}
              </AppText>
            }
            renderItem={renderItemReceita}
          />
        )}
      </View>

      <CarrinhoAlimentosBar quantidade={carrinho.length} onPress={() => setSheetCarrinho(true)} />

      <CarrinhoAlimentosSheet
        visivel={sheetCarrinho}
        itens={carrinho}
        onFechar={() => setSheetCarrinho(false)}
        onIncrementar={incrementarItem}
        onDecrementar={decrementarItem}
        onRemover={removerDoCarrinho}
        onRegistrar={handleRegistrar}
        registrando={enviando}
      />

      <ReceitaDetalheSheet
        receita={receitaAberta}
        onFechar={() => setReceitaAberta(null)}
        onAdicionarAoCarrinho={adicionarReceitaAoCarrinho}
        onEnviarParaAmigo={(r) => {
          // fecha o detalhe antes: dois Modals abertos ao mesmo tempo falham no iOS
          setReceitaAberta(null);
          // espera a animação de fechar terminar; abrir já no mesmo tick também falha no iOS
          setTimeout(() => setReceitaParaEnviar({ id: r.id, titulo: r.titulo }), 450);
        }}
      />
      <EnviarReceitaSheet receita={receitaParaEnviar} onFechar={() => setReceitaParaEnviar(null)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: colors.white ?? '#fff' },
  cabecalho: { flexDirection: 'row', marginTop: 30, alignItems: 'center', paddingHorizontal: 20, paddingTop: 12, paddingBottom: 12, gap: 12 },
  tituloBloco: { flex: 1, alignItems: 'center' },
  titulo: { fontFamily: typography.bold, fontSize: 18, color: colors.primaryDark, textAlign: 'center' },
  subtitulo: { fontFamily: typography.regular, fontSize: 12, color: '#7A8B94', textAlign: 'center', marginTop: 2 },
  corpo: { flex: 1, paddingHorizontal: 24, paddingTop: 8 },
  buscaLinha: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 20 },
  buscaCaixa: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1.5, borderColor: '#D9E2E8', borderRadius: 24, paddingHorizontal: 16, paddingVertical: 10 },
  buscaInput: { flex: 1, fontFamily: typography.regular, fontSize: 14, color: colors.primaryDark },
  botaoInfo: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#8BC34A', alignItems: 'center', justifyContent: 'center' },
  botaoAdicionar: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#8BC34A', alignItems: 'center', justifyContent: 'center' },
  botaoFiltroAberto: { backgroundColor: colors.primaryDark },
  pontoFiltro: { position: 'absolute', top: 4, right: 4, width: 8, height: 8, borderRadius: 4, backgroundColor: '#FF9800', borderWidth: 1, borderColor: '#fff' },
  painelFiltros: { gap: 2, marginBottom: 12 },
  limparFiltros: { alignSelf: 'flex-start', paddingVertical: 4 },
  limparFiltrosTexto: { fontFamily: typography.bold, fontSize: 12, color: colors.primaryDark, textDecorationLine: 'underline' },
  abasLinha: { flexDirection: 'row', gap: 50, marginBottom: 20, justifyContent: 'center' },
  aba: { alignItems: 'center', gap: 6, paddingVertical: 4 },
  abaTextoAtivo: { fontFamily: typography.bold, fontSize: 12, color: colors.primaryDark },
  secaoLabel: { fontFamily: typography.bold, fontSize: 12, color: '#7A8B94', marginBottom: 8, textTransform: 'uppercase' },
  vazioTexto: { fontFamily: typography.regular, fontSize: 13, color: '#7A8B94', textAlign: 'center', marginTop: 20, paddingHorizontal: 12 },
  itemCard: {
    marginBottom: 4,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderWidth: 1.5, borderColor: '#D9E2E8', borderRadius: 16,
    paddingVertical: 12, paddingHorizontal: 16,
  },
  itemNome: { fontFamily: typography.bold, fontSize: 15, color: colors.primaryDark, flex: 1 },
  itemClassificacao: { fontFamily: typography.regular, fontSize: 11, color: '#7A8B94', marginTop: 2 },
  botaoAdicionarPequeno: { width: 26, height: 26, borderRadius: 13, backgroundColor: '#8BC34A', alignItems: 'center', justifyContent: 'center' },
  abaIcone: { width: 72, height: 72, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  abaTexto: { fontFamily: typography.medium, fontSize: 12, color: '#7A8B94' },
});