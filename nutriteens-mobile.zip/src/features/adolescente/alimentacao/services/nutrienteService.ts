// src/features/adolescente/services/nutrienteService.ts
import { supabase } from '../../../../lib/supabase';
import type { LacunaNutriente } from '../utils/regraFeedbackRefeicao';
import { alimentoEBoaFonte, nutrientesAlcancaveis, type NutrienteChave } from '../utils/nutrientesPorGrupo';
import { formatarDataISO } from '../../../../shared/utils/data';

// alimento_nutrientes guarda um nível categórico (AUSENTE / FONTE /
// ALTO_TEOR) em vez de mg/mcg exatos — decisão tomada porque nem todo
// alimento tem dado numérico completo e confiável (ver migração
// migracao_alimento_nutrientes_categorico.sql). Por isso a lógica de
// "lacuna da semana" é CONTAGEM DE DIAS com pelo menos uma boa fonte vs.
// um mínimo de dias — acha o nutriente pior coberto sem precisar de
// valor numérico exato.
//
// Lista ampliada (era só vitamina_c/ferro/calcio/vitamina_a/zinco, os 5
// que o código já lia antes da conversão). Curadoria pensada pro que
// mais importa NESSA fase — adolescência é pico de crescimento ósseo e
// muscular, e é quando mais aparece deficiência de ferro (em especial
// pós-menarca):
//   - cálcio, vitamina D, magnésio: formação óssea (o pico de massa
//     óssea acontece na adolescência, é a "janela" que não volta)
//   - ferro, zinco: crescimento e maior prevalência de deficiência
//     nessa faixa etária
//   - vitamina A, vitamina C: imunidade e ficam fáceis de cobrir com
//     fruta/vegetal, bom pra missão “de baixo esforço”
//   - proteína, fibra: os dois macros que valem destacar como
//     benefício (diferente de carboidrato/gordura, que são neutros —
//     ver alimento_nutrientes/AlimentoFormScreen)
//
// Ficaram de fora por enquanto (dá pra incluir depois se fizer
// sentido): as vitaminas do complexo B (tiamina/riboflavina/niacina/
// piridoxina) e fósforo/potássio — geralmente bem cobertos pela dieta
// brasileira típica (inclusive em excesso, no caso do fósforo em
// ultraprocessado), então rotacioná-los como "missão" traria menos
// valor prático que os 9 abaixo. Sódio/carboidrato/gordura não entram
// aqui de propósito: são a escala de ATENÇÃO (ver
// nutrientesPorGrupo.ts), o oposto de uma lacuna — não faz sentido
// "convidar a comer mais sódio".
export const META_SEMANAL: Partial<Record<NutrienteChave, { coluna: NutrienteChave; minimoDias: number; rotulo: string; sugestao: string }>> = {
  vitamina_a: { coluna: 'vitamina_a', minimoDias: 3, rotulo: 'vitamina A', sugestao: 'cenoura, manga ou folhas verde-escuras' },
  vitamina_c: { coluna: 'vitamina_c', minimoDias: 3, rotulo: 'vitamina C', sugestao: 'uma fruta cítrica, como laranja ou acerola' },
  vitamina_d: { coluna: 'vitamina_d', minimoDias: 3, rotulo: 'vitamina D', sugestao: 'ovo, peixe ou um pouquinho de sol' },
  calcio:     { coluna: 'calcio',     minimoDias: 3, rotulo: 'cálcio',     sugestao: 'leite, iogurte ou queijo' },
  ferro:      { coluna: 'ferro',      minimoDias: 3, rotulo: 'ferro',      sugestao: 'feijão, carne vermelha ou folhas verde-escuras' },
  zinco:      { coluna: 'zinco',      minimoDias: 3, rotulo: 'zinco',      sugestao: 'carnes, ovos ou castanhas' },
  magnesio:   { coluna: 'magnesio',   minimoDias: 3, rotulo: 'magnésio',   sugestao: 'castanhas, sementes ou feijão' },
  proteina:   { coluna: 'proteina',   minimoDias: 4, rotulo: 'proteína',   sugestao: 'carne, ovo, feijão ou leite' },
  fibra:      { coluna: 'fibra',      minimoDias: 4, rotulo: 'fibra',      sugestao: 'frutas com casca, feijão ou verduras' },
  // as demais chaves de NutrienteChave (B1/B2/B3/B6, fósforo, potássio)
  // ficam de fora do rodízio de missão semanal de propósito — ver
  // justificativa no comentário acima do tipo.
};

// conta em quantos dos últimos 7 dias o usuário comeu pelo menos um
// alimento marcado como boa fonte (FONTE ou ALTO_TEOR) daquele nutriente
export async function diasComBoaFonteNaSemana(userId: string, coluna: NutrienteChave): Promise<number> {
  const hoje = new Date();
  const seteDiasAtras = new Date(hoje);
  seteDiasAtras.setDate(hoje.getDate() - 6);

  const { data, error } = await supabase
    .from('registros_diarios')
    .select(`
      data,
      refeicoes (
        refeicao_alimentos (
          alimentos ( grupos_alimentares, alimento_nutrientes ( ${coluna} ) )
        )
      )
    `)
    .eq('user_id', userId)
    .gte('data', formatarDataISO(seteDiasAtras))
    .lte('data', formatarDataISO(hoje));

  if (error) throw error;

  let diasComFonte = 0;
  for (const dia of data ?? []) {
    const teveFonteNesseDia = ((dia as any).refeicoes ?? []).some((refeicao: any) =>
      (refeicao.refeicao_alimentos ?? []).some((item: any) => alimentoEBoaFonte(item.alimentos, coluna))
    );
    if (teveFonteNesseDia) diasComFonte += 1;
  }
  return diasComFonte;
}

// Nutrientes que algum alimento do catálogo consegue cumprir. Sem isso, nutriente sem dado
// (ex.: vitamina D) virava "lacuna" eterna e a missão nunca podia ser concluída.
// Cache curto (o catálogo muda raramente). Se a consulta falhar, devolve null = não filtra nada.
let cacheAlcancaveis: { em: number; chaves: Set<NutrienteChave> } | null = null;
const TTL_ALCANCAVEIS_MS = 10 * 60 * 1000;

async function buscarNutrientesAlcancaveis(): Promise<Set<NutrienteChave> | null> {
  if (cacheAlcancaveis && Date.now() - cacheAlcancaveis.em < TTL_ALCANCAVEIS_MS) return cacheAlcancaveis.chaves;
  const chaves = Object.keys(META_SEMANAL) as NutrienteChave[];
  const { data, error } = await supabase
    .from('alimentos')
    .select(`grupos_alimentares, alimento_nutrientes ( ${chaves.join(', ')} )`);
  if (error || !data) return null;
  const set = nutrientesAlcancaveis(data as any[], chaves);
  cacheAlcancaveis = { em: Date.now(), chaves: set };
  return set;
}

// Lista TODAS as lacunas da semana, da pior pra menos pior (a de menos dias
// com boa fonte, proporcionalmente ao mínimo exigido — assim um nutriente
// com minimoDias maior, como proteína/fibra, não "ganha" injustamente só
// por pedir mais dias). Em empate, vale a ordem de META_SEMANAL.
export async function listarLacunasNutriente(userId: string): Promise<LacunaNutriente[]> {
  const lacunas: { folga: number; lacuna: LacunaNutriente }[] = [];
  const alcancaveis = await buscarNutrientesAlcancaveis();

  for (const [chave, meta] of Object.entries(META_SEMANAL) as [NutrienteChave, NonNullable<(typeof META_SEMANAL)[NutrienteChave]>][]) {
    if (alcancaveis && !alcancaveis.has(chave)) continue; // ninguém consegue cumprir: não vira lacuna
    const dias = await diasComBoaFonteNaSemana(userId, meta.coluna);
    const folga = dias - meta.minimoDias;
    if (folga < 0) lacunas.push({ folga, lacuna: { nutriente: chave, rotulo: meta.rotulo, sugestao: meta.sugestao } });
  }
  // sort é estável: empates mantêm a ordem de META_SEMANAL
  return lacunas.sort((a, b) => a.folga - b.folga).map((l) => l.lacuna);
}

// só reporta UMA lacuna (a pior), pra não empilhar vários pedidos na mesma
// mensagem/missão. `evitar` permite pular nutrientes (ex.: o da missão de
// ontem, pra não repetir a mesma missão dia após dia).
export async function detectarLacunaNutriente(userId: string, evitar: string[] = []): Promise<LacunaNutriente | null> {
  const lacunas = await listarLacunasNutriente(userId);
  return lacunas.find((l) => !evitar.includes(l.nutriente)) ?? null;
}
