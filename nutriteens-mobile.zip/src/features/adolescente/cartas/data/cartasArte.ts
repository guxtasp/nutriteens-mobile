import type { ImageSourcePropType } from 'react-native';

/**
 * ARTE DAS CARTAS DOS 10 PASSOS — PLACEHOLDERS.
 *
 * A arte vive aqui (no app), indexada por `cartas_guia.codigo`, e NÃO no banco:
 * nenhuma tela de admin consegue trocá-la (mesmo padrão de insigniasArte.ts).
 * Enquanto o design não entrega a ilustração, a chave fica `null` e o app mostra
 * o placeholder (emoji + cor) em <CartaArte />.
 *
 * Quando a arte chegar: salve em assets/img/cartas/<codigo>.png e troque `null` por
 * `require('../../../../../assets/img/cartas/<codigo>.png')`.
 * Sugestão de formato: PNG com fundo transparente, quadrado, ~600x600.
 */
export const ARTE_CARTAS: Record<string, ImageSourcePropType | null> = {
  passo_01_comida_de_verdade: require("../../../../../assets/img/cartas/passo_01_comida_de_verdade.png"),
  passo_02_tempero_na_medida: require("../../../../../assets/img/cartas/passo_02_tempero_na_medida.png"),
  passo_03_calma_nos_processados: require("../../../../../assets/img/cartas/passo_03_calma_nos_processados.png"),
  passo_04_fora_ultraprocessados: require("../../../../../assets/img/cartas/passo_04_fora_ultraprocessados.png"),
  passo_05_com_calma_e_companhia: require("../../../../../assets/img/cartas/passo_05_com_calma_e_companhia.png"),
  passo_06_compras_com_variedade: require("../../../../../assets/img/cartas/passo_06_compras_com_variedade.png"),
  passo_07_mao_na_massa: require("../../../../../assets/img/cartas/passo_07_mao_na_massa.png"),
  passo_08_tempo_para_comer_bem: require("../../../../../assets/img/cartas/passo_08_tempo_para_comer_bem.png"),
  passo_09_fora_de_casa: require("../../../../../assets/img/cartas/passo_09_fora_de_casa.png"),
  passo_10_olho_na_propaganda: require("../../../../../assets/img/cartas/passo_10_olho_na_propaganda.png"),
};

/** Emoji exibido dentro do placeholder, só para dar identidade temporária. */
export const EMOJI_CARTA: Record<string, string> = {
  passo_01_comida_de_verdade: '🥦',
  passo_02_tempero_na_medida: '🧂',
  passo_03_calma_nos_processados: '🧀',
  passo_04_fora_ultraprocessados: '🚫',
  passo_05_com_calma_e_companhia: '🧑‍🤝‍🧑',
  passo_06_compras_com_variedade: '🛒',
  passo_07_mao_na_massa: '🍳',
  passo_08_tempo_para_comer_bem: '⏰',
  passo_09_fora_de_casa: '🍽️',
  passo_10_olho_na_propaganda: '🔍',
};

export const EMOJI_PADRAO = '🍽️';

export function emojiDaCarta(codigo: string): string {
  return EMOJI_CARTA[codigo] ?? EMOJI_PADRAO;
}

/** Cores do placeholder (fundo suave + contorno), repetidas em ciclo pelos passos. */
/** Cores das cartas — alinhadas à identidade visual das artes finais. */
export const PALETA_CARTAS: { fundo: string; borda: string }[] = [
  // 01 — Comida de Verdade
  {
    fundo: '#E5F4D8',
    borda: '#69B84F',
  },

  // 02 — Tempero na Medida
  {
    fundo: '#FFF1C2',
    borda: '#E5A51A',
  },

  // 03 — Calma nos Ultraprocessados
  {
    fundo: '#FFF0B5',
    borda: '#E5A20A',
  },

  // 04 — Ultraprocessados? Fora!
  {
    fundo: '#FBE0DC',
    borda: '#E8665B',
  },

  // 05 — Com Calma e Companhia
  // provisória — aguardando arte final
  {
    fundo: '#EDE4F8',
    borda: '#9A78C7',
  },

  // 06 — Compras com Variedade
  {
    fundo: '#D9F3EE',
    borda: '#25B7A5',
  },

  // 07 — Mão na Massa
  // provisória — aguardando arte final
  {
    fundo: '#FFE5D2',
    borda: '#ED8A45',
  },

  // 08 — Tempo para Comer Bem
  {
    fundo: '#D8F1EC',
    borda: '#168D87',
  },

  // 09 — Fora de Casa, Comida na Hora
  {
    fundo: '#FFE0CC',
    borda: '#F07835',
  },

  // 10 — De Olho na Propaganda
  {
    fundo: '#DCE7FA',
    borda: '#2859A6',
  },
];

export function corDoPasso(passo: number): { fundo: string; borda: string } {
  return PALETA_CARTAS[(Math.max(passo, 1) - 1) % PALETA_CARTAS.length];
}
