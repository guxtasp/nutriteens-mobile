import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Modal, Pressable, StyleSheet, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { AppText } from '../../../../shared/ui/AppText';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import { corDoPasso } from '../data/cartasArte';
import { rotuloPasso, type CartaGuia } from '../utils/cartas';
import { CartaArte } from './CartaArte';

type Props = { carta: CartaGuia | null; onFechar: () => void };

/**
 * Carta grande. Obtida: toque para virar (frente = arte + título, verso = o que o Guia diz
 * + dica). Bloqueada: uma face só, com "como ganhar".
 */
export function CartaDetalheModal({ carta, onFechar }: Props) {
  const { width, height } = useWindowDimensions();
  const larguraCarta = Math.min(width - 48, 340);
  const alturaCarta = Math.min(height * 0.7, larguraCarta * 1.45);

  const giro = useRef(new Animated.Value(0)).current;
  const [virada, setVirada] = useState(false);

  // cada carta que abre começa de frente
  useEffect(() => {
    giro.setValue(0);
    setVirada(false);
  }, [carta?.id, giro]);

  if (!carta) return null;

  const cor = corDoPasso(carta.passo);

  function virar() {
    Haptics.selectionAsync();
    Animated.timing(giro, {
      toValue: virada ? 0 : 1,
      duration: 380,
      easing: Easing.inOut(Easing.cubic),
      useNativeDriver: true,
    }).start();
    setVirada((v) => !v);
  }

  const rotacaoFrente = giro.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '180deg'] });
  const rotacaoVerso = giro.interpolate({ inputRange: [0, 1], outputRange: ['180deg', '360deg'] });
  const tamanhoCarta = { width: larguraCarta, height: alturaCarta };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onFechar}>
      <View style={styles.raiz}>
        <Pressable style={styles.fundo} onPress={onFechar} accessibilityLabel="Fechar carta" />

        <View style={styles.centro} pointerEvents="box-none">
          {carta.obtida ? (
            // um Pressable só vira a carta; as duas faces não recebem toque (evita o verso "escondido" roubar o gesto)
            <Pressable
              onPress={virar}
              style={tamanhoCarta}
              accessibilityRole="button"
              accessibilityLabel={`${rotuloPasso(carta.passo)}: ${carta.titulo}. Toque para ${virada ? 'ver a frente' : 'ler o que o Guia diz'}.`}
            >
              <Animated.View
                pointerEvents="none"
                style={[
                  styles.face,
                  tamanhoCarta,
                  { borderColor: cor.borda, transform: [{ perspective: 1000 }, { rotateY: rotacaoFrente }] },
                ]}
              >
                <View style={[styles.faixa, { backgroundColor: cor.fundo }]}>
                  <AppText style={styles.passo}>{rotuloPasso(carta.passo)} DO GUIA</AppText>
                </View>
                <View style={styles.arte}>
                  <CartaArte codigo={carta.codigo} passo={carta.passo} tamanho={larguraCarta} />
                </View>
                <AppText style={styles.titulo}>{carta.titulo}</AppText>
                <View style={styles.dicaVirar}>
                  <Ionicons name="sync-outline" size={14} color={colors.placeholder} />
                  <AppText style={styles.dicaVirarTexto}>Toque para virar</AppText>
                </View>
              </Animated.View>

              <Animated.View
                pointerEvents="none"
                style={[
                  styles.face,
                  styles.verso,
                  tamanhoCarta,
                  { borderColor: cor.borda, transform: [{ perspective: 1000 }, { rotateY: rotacaoVerso }] },
                ]}
              >
                <View style={[styles.faixa, { backgroundColor: cor.fundo }]}>
                  <AppText style={styles.passo}>{carta.titulo.toUpperCase()}</AppText>
                </View>
                <View style={styles.versoCorpo}>
                  <AppText style={styles.secao}>O QUE O GUIA DIZ</AppText>
                  <AppText style={styles.texto}>{carta.resumo}</AppText>
                  <View style={[styles.dicaCaixa, { backgroundColor: cor.fundo }]}>
                    <AppText style={styles.secao}>NA PRÁTICA</AppText>
                    <AppText style={styles.texto}>{carta.dica}</AppText>
                  </View>
                </View>
                <View style={styles.dicaVirar}>
                  <Ionicons name="sync-outline" size={14} color={colors.placeholder} />
                  <AppText style={styles.dicaVirarTexto}>Toque para voltar</AppText>
                </View>
              </Animated.View>
            </Pressable>
          ) : (
            <View style={[styles.face, tamanhoCarta, styles.faceBloqueada]}>
              <View style={[styles.faixa, { backgroundColor: colors.trilhaNoBloqueadoFace }]}>
                <AppText style={[styles.passo, { color: colors.placeholder }]}>{rotuloPasso(carta.passo)} DO GUIA</AppText>
              </View>
              <View style={styles.arte}>
                <View style={styles.cadeadoCaixa}>
                  <Ionicons name="lock-closed" size={larguraCarta * 0.22} color={colors.trilhaNoBloqueadoIcone} />
                </View>
              </View>
              <AppText style={[styles.titulo, { color: colors.trilhaChipTexto }]}>{carta.titulo}</AppText>
              <View style={styles.comoGanharCaixa}>
                <AppText style={styles.secao}>COMO GANHAR</AppText>
                <AppText style={styles.texto}>{carta.comoGanhar}</AppText>
              </View>
            </View>
          )}
        </View>

        <Pressable style={styles.fechar} onPress={onFechar} hitSlop={10} accessibilityRole="button" accessibilityLabel="Fechar">
          <Ionicons name="close" size={22} color="#fff" />
        </Pressable>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  raiz: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  fundo: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.6)' },
  centro: { alignItems: 'center', justifyContent: 'center' },
  face: {
    position: 'absolute',
    backgroundColor: '#fff',
    borderRadius: 24,
    borderWidth: 4,
    overflow: 'hidden',
    alignItems: 'center',
    backfaceVisibility: 'hidden',
  },
  verso: { alignItems: 'stretch' },
  faceBloqueada: { position: 'relative', borderColor: colors.trilhaNoBloqueadoBorda, backgroundColor: '#F4F5F4' },
  faixa: { alignSelf: 'stretch', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 12 },
  passo: { fontSize: 12, fontFamily: typography.bold, color: colors.primaryDark, letterSpacing: 0.8, textAlign: 'center' },
  arte: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  titulo: {
    paddingHorizontal: 20,
    marginBottom: 12,
    fontSize: 22,
    fontFamily: typography.bold,
    color: colors.primaryDark,
    textAlign: 'center',
  },
  dicaVirar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingBottom: 14 },
  dicaVirarTexto: { fontSize: 12, fontFamily: typography.semiBold, color: colors.placeholder },
  versoCorpo: { flex: 1, paddingHorizontal: 20, paddingTop: 16, gap: 8 },
  secao: { fontSize: 11, fontFamily: typography.bold, color: colors.primaryDark, letterSpacing: 0.6 },
  texto: { fontSize: 14, lineHeight: 21, fontFamily: typography.regular, color: colors.trilhaChipTexto },
  dicaCaixa: { marginTop: 8, borderRadius: 16, padding: 14, gap: 6 },
  cadeadoCaixa: {
    width: 110,
    height: 110,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.trilhaNoBloqueadoFace,
  },
  comoGanharCaixa: {
    alignSelf: 'stretch',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 14,
    gap: 6,
    backgroundColor: '#fff',
  },
  fechar: {
    position: 'absolute',
    top: 56,
    right: 20,
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
});
