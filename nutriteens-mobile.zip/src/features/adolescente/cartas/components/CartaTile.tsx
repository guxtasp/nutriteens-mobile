import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppText } from '../../../../shared/ui/AppText';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import { corDoPasso } from '../data/cartasArte';
import { rotuloPasso, type CartaGuia } from '../utils/cartas';
import { CartaArte } from './CartaArte';

type Props = { carta: CartaGuia; largura: number; onPress: (c: CartaGuia) => void };

/** Carta pequena do álbum. Bloqueada: cinza com cadeado (o título aparece, o Guia é público). */
export function CartaTile({ carta, largura, onPress }: Props) {
  const cor = corDoPasso(carta.passo);
  const arte = largura * 0.58;

  return (
    <Pressable
      onPress={() => onPress(carta)}
      style={[
        styles.carta,
        { width: largura },
        carta.obtida ? { backgroundColor: '#fff', borderColor: cor.borda } : styles.bloqueada,
      ]}
      accessibilityRole="button"
      accessibilityLabel={
        carta.obtida
          ? `${rotuloPasso(carta.passo)}: ${carta.titulo}${carta.nova ? ', carta nova' : ''}`
          : `${rotuloPasso(carta.passo)}: ${carta.titulo}, bloqueada`
      }
    >
      <View style={[styles.faixa, { backgroundColor: carta.obtida ? cor.fundo : colors.trilhaNoBloqueadoFace }]}>
        <AppText style={[styles.passo, !carta.obtida && styles.passoBloqueado]}>{rotuloPasso(carta.passo)}</AppText>
      </View>

      <View style={styles.arte}>
        {carta.obtida ? (
          <CartaArte codigo={carta.codigo} passo={carta.passo} tamanho={arte} />
        ) : (
          <View
            style={[
              styles.cadeadoCaixa,
              { width: arte, height: arte, borderRadius: arte * 0.22 },
            ]}
          >
            <Ionicons name="lock-closed" size={arte * 0.4} color={colors.trilhaNoBloqueadoIcone} />
          </View>
        )}
      </View>

      <AppText numberOfLines={2} style={[styles.titulo, !carta.obtida && styles.tituloBloqueado]}>
        {carta.titulo}
      </AppText>

      {carta.nova && <View style={styles.pontoNovo} />}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  carta: {
    borderRadius: 18,
    borderWidth: 3,
    paddingBottom: 12,
    alignItems: 'center',
    overflow: 'hidden',
  },
  bloqueada: { backgroundColor: '#F4F5F4', borderColor: colors.trilhaNoBloqueadoBorda },
  faixa: { alignSelf: 'stretch', alignItems: 'center', paddingVertical: 6 },
  passo: { fontSize: 11, fontFamily: typography.bold, color: colors.primaryDark, letterSpacing: 0.5 },
  passoBloqueado: { color: colors.placeholder },
  arte: { marginTop: 12, marginBottom: 8, alignItems: 'center', justifyContent: 'center' },
  cadeadoCaixa: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.trilhaNoBloqueadoFace,
  },
  titulo: {
    paddingHorizontal: 8,
    minHeight: 32,
    fontSize: 12,
    fontFamily: typography.bold,
    color: colors.primaryDark,
    textAlign: 'center',
  },
  tituloBloqueado: { color: colors.placeholder },
  pontoNovo: {
    position: 'absolute',
    top: 6,
    right: 8,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: colors.exercicioErro,
    borderWidth: 2,
    borderColor: '#fff',
  },
});
