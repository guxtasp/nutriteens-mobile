import React from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { AppText } from '../../../../shared/ui/AppText';
import { ARTE_CARTAS, corDoPasso, emojiDaCarta } from '../data/cartasArte';

type Props = {
  codigo: string;
  passo: number;
  /** lado do quadrado da arte */
  tamanho: number;
};

/**
 * Arte da carta. Sem ilustração em ARTE_CARTAS -> placeholder (emoji sobre fundo colorido).
 * Quando o design entregar o PNG, só o mapa em data/cartasArte.ts muda.
 */
export function CartaArte({ codigo, passo, tamanho }: Props) {
  const arte = ARTE_CARTAS[codigo];
  const cor = corDoPasso(passo);

  const tamanhoLimitado = Math.min(tamanho, 600);

  if (arte) {
    return (
      <Image
        source={arte}
        style={{
          width: tamanhoLimitado,
          height: tamanhoLimitado,
        }}
        resizeMode="contain"
      />
    );
  }

  return (
    <View
      style={[
        styles.placeholder,
        {
          width: tamanhoLimitado,
          height: tamanhoLimitado,
          borderRadius: tamanhoLimitado * 0.22,
          backgroundColor: cor.fundo,
          borderColor: cor.borda,
        },
      ]}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      <AppText style={{ fontSize: tamanhoLimitado * 0.5 }}>
        {emojiDaCarta(codigo)}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  placeholder: { alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderStyle: 'dashed' },
});
