// src/features/adolescente/agua/screens/ConsumoAguaScreen.tsx
import React, { useState, useCallback, useEffect } from 'react';
import { View, StyleSheet, Pressable, Alert, InteractionManager, ScrollView } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { AdolescenteStackParamList } from '../../../../navigation/AdolescenteNavigator';
import { AppText } from '../../../../shared/ui/AppText';
import { ScreenHeader } from '../../../../shared/ui/ScreenHeader';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import { tocarSom } from '../../../../shared/audio/sons';
import { useAguaHoje } from '../../agua/hooks/useAguaHoje';
import GarrafaAnimada from '../../agua/components/GarrafaAnimada';
import AguaSlider from '../../agua/components/AguaSlider';
import PesoAlturaModal from '../../perfil/components/PesoAlturaModal';
import GuiaAguaSheet from '../../agua/components/GuiaAguaSheet';
import SucessoRegistroModal from '../../_shared/components/SucessoRegistroModal';
import { feedbackAgua, type FeedbackRegistro } from '../../_shared/utils/feedbackRegistro';

type NavigationProp = NativeStackNavigationProp<AdolescenteStackParamList, 'ConsumoAgua'>;

export default function ConsumoAguaScreen() {
  const navigation = useNavigation<NavigationProp>();
  const insets = useSafeAreaInsets();
  const {
    precisaPesoAltura,
    metaMl,
    mlHoje,
    mediaSemanal,
    mediaMensal,
    registrando,
    progresso,
    salvarPesoAltura,
    registrar,
  } = useAguaHoje();

  const [quantidadeSelecionada, setQuantidadeSelecionada] = useState(200);
  const [sheetGuia, setSheetGuia] = useState(false);
  const [sucessoVisivel, setSucessoVisivel] = useState(false);
  const [feedback, setFeedback] = useState<FeedbackRegistro | null>(null);
  // "Agora não" no modal de peso: a tela segue usável com a meta padrão
  const [pesoDispensado, setPesoDispensado] = useState(false);
  // iOS: um Modal que tenta abrir no meio da transição de entrada da tela (ou com o menu "+" ainda
  // se fechando) falha em silêncio e deixa a tela inteira sem resposta ao toque. O dado do perfil chega
  // rápido, então o modal de peso só pode aparecer depois que a tela assentou.
  const [telaAssentou, setTelaAssentou] = useState(false);
  useEffect(() => {
    let cancelado = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const tarefa = InteractionManager.runAfterInteractions(() => {
      timer = setTimeout(() => {
        if (!cancelado) setTelaAssentou(true);
      }, 500);
    });
    return () => {
      cancelado = true;
      tarefa.cancel();
      if (timer) clearTimeout(timer);
    };
  }, []);

  const handleRegistrar = useCallback(async () => {
    try {
      const novoTotal = await registrar(quantidadeSelecionada);
      if (novoTotal == null) return;
      setFeedback(
        feedbackAgua({ registradoMl: quantidadeSelecionada, totalAntesMl: mlHoje, totalDepoisMl: novoTotal, metaMl })
      );
      // fanfarra só na hora em que a meta é batida; nos outros registros, a gota
      const cruzouAMeta = mlHoje < metaMl && novoTotal >= metaMl;
      tocarSom(cruzouAMeta ? 'fanfarra' : 'gota');
      setSucessoVisivel(true);
    } catch (erro) {
      console.error('Erro ao registrar água:', erro);
      Alert.alert('Ops', 'Não foi possível registrar agora. Tente de novo.');
    }
  }, [registrar, quantidadeSelecionada, metaMl, mlHoje]);

  return (
    <SafeAreaView style={styles.tela}>
      <ScreenHeader
        titulo="Consumo de água"
        subtitulo="Resumo diário do seu consumo de água"
        onVoltar={() => navigation.goBack()}
      />

      {/* rolável: em telas baixas (e no web) o conteúdo passa da altura e o botão ficava cortado/colado embaixo */}
      <ScrollView
        style={styles.corpo}
        contentContainerStyle={[styles.corpoConteudo, { paddingBottom: Math.max(insets.bottom, 0) + 32 }]}
        showsVerticalScrollIndicator={false}
        bounces={false}
      >
        <View style={styles.garrafaBloco}>
          <GarrafaAnimada progresso={progresso} />

          <View style={styles.infoDireita}>
            <Pressable style={styles.botaoInfo} onPress={() => setSheetGuia(true)}>
              <Ionicons name="information" size={18} color="#fff" />
            </Pressable>
            <AppText style={styles.rotuloHoje}>Hoje</AppText>
            <AppText style={styles.valorHoje}>{mlHoje} ml</AppText>
            <AppText style={styles.meta}>Meta: {metaMl} ml</AppText>
          </View>
        </View>

        <View style={styles.progressoLinha}>
          <View style={styles.cardProgresso}>
            <View style={styles.cardProgressoTopo}>
              <Ionicons name="trending-up" size={14} color={colors.primaryDark} />
              <AppText style={styles.cardProgressoLabel}>Seu progresso semanal</AppText>
            </View>
            <AppText style={styles.cardProgressoValor}>
              {mediaSemanal} <AppText style={styles.cardProgressoUnidade}>ml</AppText>
            </AppText>
            <AppText style={styles.cardProgressoSub}>(Média)</AppText>
          </View>

          <View style={styles.cardProgresso}>
            <View style={styles.cardProgressoTopo}>
              <Ionicons name="trending-up" size={14} color={colors.primaryDark} />
              <AppText style={styles.cardProgressoLabel}>Seu progresso mensal</AppText>
            </View>
            <AppText style={styles.cardProgressoValor}>
              {mediaMensal} <AppText style={styles.cardProgressoUnidade}>ml</AppText>
            </AppText>
            <AppText style={styles.cardProgressoSub}>(Média)</AppText>
          </View>
        </View>

        <AppText style={styles.pergunta}>Quantos ml você consumiu?</AppText>

        <AguaSlider valor={quantidadeSelecionada} onChange={setQuantidadeSelecionada} step={100} min={0} max={1000} />
        <Pressable
          style={[styles.botaoRegistrar, registrando && { opacity: 0.6 }]}
          onPress={handleRegistrar}
          disabled={registrando}
        >
          <AppText style={styles.botaoRegistrarTexto}>REGISTRE AQUI</AppText>
        </Pressable>
      </ScrollView>

      <PesoAlturaModal
        visivel={telaAssentou && precisaPesoAltura && !pesoDispensado}
        onConfirmar={salvarPesoAltura}
        onFechar={() => setPesoDispensado(true)}
      />
      <GuiaAguaSheet visivel={sheetGuia} onFechar={() => setSheetGuia(false)} />
      <SucessoRegistroModal
        visivel={sucessoVisivel}
        quantidade={quantidadeSelecionada}
        titulo={feedback?.titulo}
        mensagem={feedback?.mensagem ?? `Você registrou ${quantidadeSelecionada}ml de água agora!`}
        onFechar={() => setSucessoVisivel(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, marginTop: 8, backgroundColor: colors.white ?? '#fff' },
  cabecalho: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 12, paddingBottom: 12, gap: 12 },
  tituloBloco: { flex: 1, alignItems: 'center' },
  titulo: { fontFamily: typography.bold, fontSize: 18, color: colors.primaryDark, textAlign: 'center' },
  subtitulo: { fontFamily: typography.regular, fontSize: 12, color: '#7A8B94', textAlign: 'center', marginTop: 2 },
  botaoInfo: { width: 25, height: 25, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  corpo: { flex: 1 },
  corpoConteudo: { paddingHorizontal: 24, paddingTop: 12 },
  garrafaBloco: { flexDirection: 'row', alignItems: 'flex-end', marginBottom: 8 },
  infoDireita: { flex: 1, alignItems: 'flex-end', paddingBottom: 40, marginLeft: 16 },
  rotuloHoje: { fontFamily: typography.medium, fontSize: 16, color: colors.primaryDark },
  valorHoje: { fontFamily: typography.bold, fontSize: 32, color: colors.primaryDark, marginTop: 4 },
  meta: { fontFamily: typography.regular, fontSize: 16, color: colors.primaryDark, marginTop: 4 },
  progressoLinha: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  cardProgresso: { flex: 1, backgroundColor: '#CDE7D6', borderRadius: 16, padding: 14 },
  cardProgressoTopo: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 },
  cardProgressoLabel: { fontFamily: typography.medium, fontSize: 11, color: colors.primaryDark, flexShrink: 1 },
  cardProgressoValor: { fontFamily: typography.bold, fontSize: 26, color: colors.primaryDark },
  cardProgressoUnidade: { fontFamily: typography.regular, fontSize: 14 },
  cardProgressoSub: { fontFamily: typography.regular, fontSize: 11, color: '#4A7A5A', marginTop: 2 },
  pergunta: { fontFamily: typography.medium, fontSize: 15, color: colors.primaryDark, textAlign: 'center', marginBottom: 5 },
  botaoRegistrar: { backgroundColor: colors.primaryDark, borderRadius: 24, paddingVertical: 16, alignItems: 'center', marginTop: 5, marginBottom: 16 },
  botaoRegistrarTexto: { fontFamily: typography.bold, fontSize: 13, color: '#fff', letterSpacing: 0.5 },
});