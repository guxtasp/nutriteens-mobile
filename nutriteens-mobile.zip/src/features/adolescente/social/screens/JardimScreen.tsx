// src/features/adolescente/social/screens/JardimScreen.tsx
//
// Jardim do grupo: uma planta compartilhada por 2 a 5 amigos. Cresce com os registros de todos e
// NUNCA murcha. Sem ranking, sem totais por pessoa e sem apontar quem não regou (ver utils/jardim.ts).
// A planta é desenhada em SVG (components/PlantaJardim.tsx): Brócolis, Girassol, Tomateiro, Laranjeira e Horta.
//
// Regar = registrar algo no dia (refeição, água ou atividade). O bloco "Regue o jardim hoje" explica isso e
// leva direto para o registro. Confirmações usam painéis dentro da tela (Alert.alert com botões não funciona na web).
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, ActivityIndicator, Animated, Easing, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { AppText } from '../../../../shared/ui/AppText';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { formatarDataISO } from '../../../../shared/utils/data';
import { feedbackConquista, feedbackToque } from '../../../../shared/audio/feedback';
import { AvatarSocialView } from '../components/AvatarSocialView';
import JardimBotao from '../components/JardimBotao';
import PlantaJardim from '../components/PlantaJardim';
import { listarAmigos, type AmigoSocial } from '../services/socialService';
import { convidarParaJardim, criarJardim, listarJardins, regarJardinsSeHojeContou, responderConviteJardim, sairDoJardim } from '../services/jardimService';
import { ehErroRestricaoSocial } from '../utils/moderacao';
import {
  ESTAGIOS_JARDIM, MAX_JARDINS_ATIVOS, MAX_MEMBROS_JARDIM, TEMAS_JARDIM, ehErroLimiteJardim, estagioDoJardim, euRegueiHoje,
  faltaRegarHoje, mensagemConviteJardim, nomeDoEstagio, progressoDoJardim, textoRegaHoje, type Jardim, type TemaJardim,
} from '../utils/jardim';

const AZUL_AGUA = '#4AA3F0';

/** Céu atrás de cada planta: combina com a cor do vaso. */
const CEU: Record<TemaJardim, [string, string]> = {
  BROCOLIS: ['#DCD2FF', '#F4FBE9'],
  GIRASSOL: ['#BFE3FF', '#FFF7D6'],
  TOMATEIRO: ['#FFE0DC', '#FFF6EA'],
  LARANJEIRA: ['#CDEFE9', '#FFF3DD'],
  HORTA: ['#FFD9E6', '#F2FBE4'],
};

function nomeDoTema(tema: TemaJardim): string {
  return TEMAS_JARDIM.find((t) => t.tema === tema)?.nome ?? 'Jardim';
}

function mensagemErro(e: unknown): string {
  if (ehErroRestricaoSocial(e)) return 'Seu espaço de amigos está em pausa por enquanto. O jardim continua crescendo com os seus registros.';
  if (ehErroLimiteJardim(e)) return `Você já participa de ${MAX_JARDINS_ATIVOS} jardins. Saia de um para criar outro.`;
  return 'Algo deu errado. Tente de novo daqui a pouco.';
}

function useReduzirMovimento(): boolean {
  const [reduzir, setReduzir] = useState(false);
  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled().then(setReduzir).catch(() => undefined);
  }, []);
  return reduzir;
}

/** Três gotinhas caindo sobre a planta quando VOCÊ regou hoje (toca 3 vezes e para). */
function Gotas({ ativo }: { ativo: boolean }) {
  const reduzir = useReduzirMovimento();
  const vals = useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  useEffect(() => {
    if (!ativo || reduzir) return;
    const loops = vals.map((v, i) => Animated.loop(
      Animated.sequence([
        Animated.delay(i * 420),
        Animated.timing(v, { toValue: 1, duration: 1200, easing: Easing.in(Easing.quad), useNativeDriver: true }),
        Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      ]),
      { iterations: 3 },
    ));
    loops.forEach((l) => l.start());
    return () => loops.forEach((l) => l.stop());
  }, [ativo, reduzir, vals]);

  if (!ativo || reduzir) return null;
  return (
    <View pointerEvents="none" style={estilos.gotas}>
      {vals.map((v, i) => (
        <Animated.View
          key={i}
          style={{
            position: 'absolute',
            left: 6 + i * 30,
            opacity: v.interpolate({ inputRange: [0, 0.15, 0.85, 1], outputRange: [0, 1, 1, 0] }),
            transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, 74] }) }],
          }}
        >
          <Ionicons name="water" size={18} color={AZUL_AGUA} />
        </Animated.View>
      ))}
    </View>
  );
}

/** "Seu jardim cresceu!" — aparece uma vez quando o estágio sobe desde a última visita. */
function AvisoCresceu({ texto, aoFechar }: { texto: string; aoFechar: () => void }) {
  const escala = useRef(new Animated.Value(0.6)).current;
  useEffect(() => {
    const a = Animated.spring(escala, { toValue: 1, friction: 4, tension: 90, useNativeDriver: true });
    a.start();
    return () => a.stop();
  }, [escala]);
  return (
    <Animated.View style={[estilos.cresceu, { transform: [{ scale: escala }] }]}>
      <Pressable onPress={aoFechar} accessibilityRole="button" accessibilityLabel={`${texto} Toque para fechar.`} style={estilos.cresceuLinha}>
        <Ionicons name="sparkles" size={18} color={colors.primaryDark} />
        <AppText style={estilos.cresceuTexto}>{texto}</AppText>
      </Pressable>
    </Animated.View>
  );
}

/** Os 7 estágios em miniatura: o atual em destaque e os que ainda vêm apagados, para dar vontade de chegar lá. */
function LinhaDoTempo({ tema, atual }: { tema: TemaJardim; atual: number }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={estilos.linhaTempo}>
      {ESTAGIOS_JARDIM.map((e) => {
        const alcancado = e.indice <= atual;
        const ehAtual = e.indice === atual;
        return (
          <View key={e.indice} style={[estilos.passo, ehAtual && estilos.passoAtual]} accessible accessibilityLabel={`${nomeDoEstagio(tema, e.indice)}${ehAtual ? ', estágio atual' : alcancado ? ', já conquistado' : ', ainda por vir'}`}>
            <PlantaJardim tema={tema} estagio={e.indice} tamanho={46} animar={false} silhueta={!alcancado} />
            <AppText style={[estilos.passoNome, !alcancado && { color: '#9AA5A0' }]} numberOfLines={1}>{nomeDoEstagio(tema, e.indice)}</AppText>
          </View>
        );
      })}
    </ScrollView>
  );
}

type RotaRegistro = 'TipoRefeicao' | 'ConsumoAgua' | 'AtividadeFisica';

const ACOES_REGAR: { rota: RotaRegistro; rotulo: string; icone: keyof typeof Ionicons.glyphMap; cor: string; fundo: string }[] = [
  { rota: 'TipoRefeicao', rotulo: 'Refeição', icone: 'restaurant', cor: '#D9731A', fundo: '#FFE9D2' },
  { rota: 'ConsumoAgua', rotulo: 'Água', icone: 'water', cor: '#2F7FC4', fundo: '#D8ECFD' },
  { rota: 'AtividadeFisica', rotulo: 'Atividade', icone: 'walk', cor: '#3E8E2F', fundo: '#DDF1CF' },
];

/** Explica como regar e leva direto ao registro. Antes não havia nada na tela dizendo o que faz a planta crescer. */
function BlocoRegar({ regouHoje, aoIr }: { regouHoje: boolean; aoIr: (rota: RotaRegistro) => void }) {
  const [comoFunciona, setComoFunciona] = useState(false);
  return (
    <LinearGradient colors={regouHoje ? ['#E4F5D3', '#F4FBEA'] : ['#DDEFFE', '#F3FAFF']} style={[estilos.regar, { borderColor: regouHoje ? '#BFE19B' : '#BFE0FA' }]}>
      <View style={estilos.regarTopo}>
        <View style={[estilos.regarIcone, { backgroundColor: regouHoje ? colors.primary : AZUL_AGUA }]}>
          <Ionicons name={regouHoje ? 'checkmark' : 'water'} size={24} color={regouHoje ? colors.primaryDark : colors.white} />
        </View>
        <View style={{ flex: 1 }}>
          <AppText style={estilos.regarTitulo}>{regouHoje ? 'Você regou hoje!' : 'Regue o jardim hoje'}</AppText>
          <AppText style={estilos.regarSub}>
            {regouHoje
              ? 'O jardim agradece. Amanhã tem mais uma regadinha.'
              : 'Registre algo do seu dia e a planta ganha 1 regadinha. Escolha um:'}
          </AppText>
        </View>
      </View>

      {!regouHoje && (
        <View style={estilos.acoesRegar}>
          {ACOES_REGAR.map((a) => (
            <Pressable
              key={a.rota}
              onPress={() => { feedbackToque(); aoIr(a.rota); }}
              accessibilityRole="button"
              accessibilityLabel={`Registrar ${a.rotulo.toLowerCase()} para regar o jardim`}
              style={({ pressed }) => [estilos.acaoRegar, pressed && { transform: [{ translateY: 2 }], borderBottomWidth: 2 }]}
            >
              <View style={[estilos.acaoRegarIcone, { backgroundColor: a.fundo }]}>
                <Ionicons name={a.icone} size={22} color={a.cor} />
              </View>
              <AppText style={estilos.acaoRegarTexto}>{a.rotulo}</AppText>
            </Pressable>
          ))}
        </View>
      )}

      <JardimBotao
        variante="texto"
        tamanho="pequeno"
        bloco={false}
        icone={comoFunciona ? 'chevron-up' : 'help-circle-outline'}
        label={comoFunciona ? 'Fechar' : 'Como funciona?'}
        onPress={() => setComoFunciona((v) => !v)}
        style={{ alignSelf: 'center' }}
      />
      {comoFunciona && (
        <View style={estilos.passos}>
          <PassoComoFunciona n={1} texto="Registre uma refeição, um copo de água ou uma atividade. Qualquer um já vale." />
          <PassoComoFunciona n={2} texto="Cada pessoa rega 1 vez por dia, e cada regadinha vira 1 ponto para a planta do grupo." />
          <PassoComoFunciona n={3} texto="Com os pontos a planta cresce de estágio. Ela nunca murcha, mesmo nos dias sem registro." />
        </View>
      )}
    </LinearGradient>
  );
}

function PassoComoFunciona({ n, texto }: { n: number; texto: string }) {
  return (
    <View style={estilos.passoLinha}>
      <View style={estilos.passoNumero}><AppText style={estilos.passoNumeroTexto}>{n}</AppText></View>
      <AppText style={estilos.passoTexto}>{texto}</AppText>
    </View>
  );
}

function CartaoJardim({ j, amigos, aoMudar }: { j: Jardim; amigos: AmigoSocial[]; aoMudar: () => void }) {
  const estagio = estagioDoJardim(j.pontos);
  const { fracao, faltam, proximo } = progressoDoJardim(j.pontos);
  const [convidando, setConvidando] = useState(false);
  const [saindo, setSaindo] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [cresceu, setCresceu] = useState(false);
  const nomesNoJardim = new Set(j.membros.map((m) => m.apelido));
  const disponiveis = amigos.filter((a) => !nomesNoJardim.has(a.apelido));
  const cheio = j.membros.length >= MAX_MEMBROS_JARDIM;
  const euRegou = euRegueiHoje(j);
  const nomeEstagio = nomeDoEstagio(j.tema, estagio.indice);

  // lembra o último estágio visto neste aparelho; se subiu, comemora
  useEffect(() => {
    let vivo = true;
    const chave = `jardim:estagio:${j.id}`;
    AsyncStorage.getItem(chave).then((v) => {
      if (!vivo) return;
      const antes = v === null ? null : Number(v);
      if (antes !== null && Number.isFinite(antes) && estagio.indice > antes) {
        setCresceu(true);
        feedbackConquista();
      }
      if (antes === null || !Number.isFinite(antes) || estagio.indice > antes) {
        void AsyncStorage.setItem(chave, String(estagio.indice)).catch(() => undefined);
      }
    }).catch(() => undefined);
    return () => { vivo = false; };
  }, [j.id, estagio.indice]);

  async function convidar(a: AmigoSocial) {
    feedbackToque();
    setOcupado(true);
    try {
      const r = await convidarParaJardim(j.id, a.amizadeId);
      setMsg(mensagemConviteJardim(r, a.apelido));
      if (r === 'enviado') { setConvidando(false); aoMudar(); }
    } catch (e) {
      setMsg(mensagemErro(e));
    } finally {
      setOcupado(false);
    }
  }

  async function confirmarSaida() {
    feedbackToque();
    setOcupado(true);
    try {
      await sairDoJardim(j.id);
      aoMudar();
    } catch (e) {
      setMsg(mensagemErro(e));
      setSaindo(false);
    } finally {
      setOcupado(false);
    }
  }

  return (
    <View style={estilos.cartao}>
      <LinearGradient colors={CEU[j.tema]} style={estilos.palco}>
        <View style={estilos.chipEstagio}>
          <Ionicons name="leaf" size={14} color={colors.primaryDark} />
          <AppText style={estilos.chipEstagioTexto}>{nomeEstagio}</AppText>
        </View>
        <View style={estilos.chipPontos} accessible accessibilityLabel={`${j.pontos} regadinhas no total`}>
          <Ionicons name="water" size={14} color={AZUL_AGUA} />
          <AppText style={estilos.chipPontosTexto}>{j.pontos}</AppText>
        </View>
        <Gotas ativo={euRegou} />
        <PlantaJardim tema={j.tema} estagio={estagio.indice} tamanho={220} />
        <View style={estilos.grama} />
        {cresceu && <AvisoCresceu texto={`Seu jardim cresceu! Agora é ${nomeEstagio.toLowerCase()}.`} aoFechar={() => setCresceu(false)} />}
      </LinearGradient>

      <View style={estilos.corpoCartao}>
        <View style={estilos.tituloLinha}>
          <AppText style={estilos.tituloCartao}>{nomeDoTema(j.tema)}</AppText>
          <AppText style={estilos.estagioNumero}>Estágio {estagio.indice + 1} de {ESTAGIOS_JARDIM.length}</AppText>
        </View>
        <View style={estilos.barraFundo}><View style={[estilos.barraCheia, { width: `${Math.max(4, Math.round(fracao * 100))}%` }]} /></View>
        <AppText style={estilos.sub}>
          {proximo
            ? `Faltam ${faltam} ${faltam === 1 ? 'regadinha' : 'regadinhas'} para virar ${nomeDoEstagio(j.tema, proximo.indice).toLowerCase()}.`
            : 'Seu jardim está completo. Continue regando para ele ficar lindo!'}
        </AppText>
        <AppText style={estilos.destaque}>{textoRegaHoje(j)}</AppText>

        <LinhaDoTempo tema={j.tema} atual={estagio.indice} />

        <View style={estilos.divisor} />
        <AppText style={estilos.rotulo}>Quem cuida deste jardim</AppText>
        <View style={estilos.membros}>
          {j.membros.map((m) => (
            <View key={m.apelido + (m.eu ? 'eu' : '')} style={[estilos.membro, m.pendente && { opacity: 0.5 }]} accessible accessibilityLabel={`${m.eu ? 'Você' : m.apelido}${m.pendente ? ', convite enviado' : m.regouHoje ? ', regou hoje' : ''}`}>
              <View>
                <AvatarSocialView avatar={m.avatar} size="small" />
                {m.regouHoje && !m.pendente && <View style={estilos.gota}><Ionicons name="water" size={12} color={colors.white} /></View>}
              </View>
              <AppText style={estilos.nomeMembro} numberOfLines={1}>{m.eu ? 'Você' : m.apelido}</AppText>
              {m.pendente && <AppText style={estilos.chegando}>convidado</AppText>}
            </View>
          ))}
        </View>

        {!!msg && (
          <View style={estilos.msgCaixa} accessibilityRole="alert">
            <Ionicons name="information-circle" size={18} color={colors.primaryDark} />
            <AppText style={estilos.msgTexto}>{msg}</AppText>
          </View>
        )}

        {saindo ? (
          <View style={estilos.confirma}>
            <AppText style={estilos.rotulo}>Sair do jardim?</AppText>
            <AppText style={estilos.sub}>O jardim continua crescendo com os outros amigos. Você pode voltar se alguém te convidar de novo.</AppText>
            <View style={estilos.confirmaBotoes}>
              <View style={{ flex: 1 }}><JardimBotao variante="contorno" label="FICAR" onPress={() => setSaindo(false)} desabilitado={ocupado} /></View>
              <View style={{ flex: 1 }}><JardimBotao variante="perigo" label="SAIR" icone="exit-outline" onPress={() => void confirmarSaida()} carregando={ocupado} /></View>
            </View>
          </View>
        ) : convidando ? (
          <View style={{ gap: 8 }}>
            <AppText style={estilos.rotulo}>Convidar quem?</AppText>
            {disponiveis.length === 0 ? (
              <AppText style={estilos.sub}>Todos os seus amigos já estão aqui ou você ainda não tem amigos adicionados.</AppText>
            ) : disponiveis.map((a) => (
              <View key={a.amizadeId} style={estilos.amigoLinha}>
                <AvatarSocialView avatar={a.avatar} size="small" />
                <AppText style={[estilos.nomeMembro, { flex: 1, fontSize: 14 }]} numberOfLines={1}>{a.apelido}</AppText>
                <JardimBotao variante="suave" tamanho="pequeno" bloco={false} icone="add" label="CONVIDAR" acessibilidade={`Convidar ${a.apelido}`} onPress={() => void convidar(a)} desabilitado={ocupado} />
              </View>
            ))}
            <JardimBotao variante="contorno" label="FECHAR" onPress={() => setConvidando(false)} />
          </View>
        ) : (
          <View style={estilos.acoesCartao}>
            {!cheio && <JardimBotao variante="primario" icone="person-add" label="CONVIDAR AMIGO" onPress={() => { setMsg(null); setConvidando(true); }} />}
            <JardimBotao variante="contorno" tamanho="pequeno" icone="exit-outline" label="Sair do jardim" onPress={() => { setMsg(null); setSaindo(true); }} />
          </View>
        )}
      </View>
    </View>
  );
}

export default function JardimScreen() {
  const navigation = useNavigation<any>();
  const { userId } = useAuth();
  const [jardins, setJardins] = useState<Jardim[]>([]);
  const [amigos, setAmigos] = useState<AmigoSocial[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [criando, setCriando] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [aviso, setAviso] = useState<string | null>(null);

  const carregar = useCallback(async () => {
    try {
      const [js0, am] = await Promise.all([listarJardins(), listarAmigos().catch(() => [] as AmigoSocial[])]);
      let js = js0;
      // Se você já registrou algo hoje mas o jardim ainda não foi regado (registrou antes de criar o jardim, ou a
      // Home ainda não foi aberta), rega agora e recarrega. Antes só a Home regava, e a planta parecia "travada".
      if (userId && faltaRegarHoje(js) && (await regarJardinsSeHojeContou(userId, formatarDataISO(new Date())))) {
        js = await listarJardins();
      }
      setJardins(js);
      setAmigos(am);
      setErro(null);
    } catch {
      setErro('Não deu para carregar seus jardins agora.');
    } finally {
      setCarregando(false);
    }
  }, [userId]);

  useFocusEffect(useCallback(() => { void carregar(); }, [carregar]));

  const convites = jardins.filter((j) => j.situacao === 'convidado');
  const ativos = jardins.filter((j) => j.situacao === 'ativo');
  const regouHoje = ativos.length > 0 && ativos.every(euRegueiHoje);

  function voltar() {
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.navigate('Social');
  }

  async function criar(tema: TemaJardim) {
    feedbackToque();
    setAviso(null);
    setOcupado(true);
    try {
      await criarJardim(tema);
      setCriando(false);
      await carregar();
    } catch (e) {
      setAviso(mensagemErro(e));
    } finally {
      setOcupado(false);
    }
  }

  async function responder(j: Jardim, aceitar: boolean) {
    feedbackToque();
    setAviso(null);
    setOcupado(true);
    try {
      const ok = await responderConviteJardim(j.id, aceitar);
      if (!ok && aceitar) setAviso('Não deu para entrar: o jardim encheu ou você já está em 3 jardins.');
      await carregar();
    } catch (e) {
      setAviso(mensagemErro(e));
    } finally {
      setOcupado(false);
    }
  }

  return (
    <SafeAreaView style={estilos.tela} edges={['top']}>
      <View style={estilos.header}>
        <Pressable onPress={voltar} style={estilos.voltar} accessibilityRole="button" accessibilityLabel="Voltar" hitSlop={8}>
          <Ionicons name="arrow-back" size={22} color={colors.primaryDark} />
        </Pressable>
        <AppText style={estilos.titulo}>Jardim do grupo</AppText>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={estilos.conteudo} showsVerticalScrollIndicator={false}>
        {!!aviso && (
          <View style={estilos.msgCaixa} accessibilityRole="alert">
            <Ionicons name="information-circle" size={18} color={colors.primaryDark} />
            <AppText style={estilos.msgTexto}>{aviso}</AppText>
          </View>
        )}

        {carregando ? <ActivityIndicator color={colors.primaryDark} style={{ marginTop: 40 }} /> : erro ? (
          <View style={{ alignItems: 'center', gap: 12, marginTop: 30 }}>
            <AppText style={estilos.sub}>{erro}</AppText>
            <JardimBotao bloco={false} icone="refresh" label="TENTAR DE NOVO" onPress={() => { setCarregando(true); void carregar(); }} />
          </View>
        ) : (
          <>
            {ativos.length > 0 && <BlocoRegar regouHoje={regouHoje} aoIr={(rota) => navigation.navigate(rota)} />}

            {convites.map((j) => (
              <View key={j.id} style={[estilos.cartaoConvite, { borderColor: AZUL_AGUA }]}>
                <View style={estilos.conviteTopo}>
                  <LinearGradient colors={CEU[j.tema]} style={estilos.conviteCeu}>
                    <PlantaJardim tema={j.tema} estagio={estagioDoJardim(j.pontos).indice} tamanho={60} animar={false} />
                  </LinearGradient>
                  <View style={{ flex: 1, gap: 4 }}>
                    <AppText style={estilos.tituloCartao}>{j.convidadoPor ?? 'Um amigo'} te chamou para um jardim de {nomeDoTema(j.tema).toLowerCase()}</AppText>
                    <AppText style={estilos.sub}>{j.membros.filter((m) => !m.pendente).length} {j.membros.filter((m) => !m.pendente).length === 1 ? 'pessoa já está' : 'pessoas já estão'} cuidando dele.</AppText>
                  </View>
                </View>
                <View style={estilos.confirmaBotoes}>
                  <View style={{ flex: 1 }}><JardimBotao variante="contorno" label="AGORA NÃO" onPress={() => void responder(j, false)} desabilitado={ocupado} /></View>
                  <View style={{ flex: 1 }}><JardimBotao variante="primario" icone="checkmark" label="ENTRAR" onPress={() => void responder(j, true)} carregando={ocupado} /></View>
                </View>
              </View>
            ))}

            {ativos.map((j) => <CartaoJardim key={j.id} j={j} amigos={amigos} aoMudar={carregar} />)}

            {ativos.length === 0 && convites.length === 0 && (
              <View style={estilos.vazio}>
                <PlantaJardim tema="BROCOLIS" estagio={0} tamanho={170} />
                <AppText style={estilos.tituloCartao}>Plante o primeiro jardim</AppText>
                <AppText style={[estilos.sub, { textAlign: 'center' }]}>Escolha uma planta e convide amigos. Cada refeição, copo de água ou atividade que vocês registram rega a planta, e quanto mais gente rega, mais ela cresce.</AppText>
              </View>
            )}

            {ativos.length < MAX_JARDINS_ATIVOS && (criando ? (
              <View style={estilos.cartaoEscolha}>
                <AppText style={estilos.tituloCartao}>Qual planta vocês vão cuidar?</AppText>
                <View style={estilos.temas}>
                  {TEMAS_JARDIM.map((t) => (
                    <Pressable
                      key={t.tema}
                      onPress={ocupado ? undefined : () => void criar(t.tema)}
                      accessibilityRole="button"
                      accessibilityLabel={`Plantar ${t.nome}. ${t.descricao}`}
                      style={({ pressed }) => [estilos.tema, pressed && { transform: [{ translateY: 2 }], borderBottomWidth: 2 }, ocupado && { opacity: 0.5 }]}
                    >
                      <LinearGradient colors={CEU[t.tema]} style={estilos.temaCeu}>
                        <PlantaJardim tema={t.tema} estagio={6} tamanho={96} animar={false} />
                      </LinearGradient>
                      <AppText style={estilos.temaNome}>{t.nome}</AppText>
                      <AppText style={estilos.temaDescricao}>{t.descricao}</AppText>
                    </Pressable>
                  ))}
                </View>
                <JardimBotao variante="contorno" label="CANCELAR" onPress={() => setCriando(false)} />
              </View>
            ) : (
              <JardimBotao variante={ativos.length === 0 ? 'primario' : 'suave'} icone="add" label="NOVO JARDIM" onPress={() => { setAviso(null); setCriando(true); }} />
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#F8FAF8' },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 8, paddingBottom: 8 },
  voltar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.white, borderWidth: 1, borderColor: '#E4E9E6' },
  titulo: { flex: 1, textAlign: 'center', fontFamily: typography.bold, fontSize: 18, color: colors.primaryDark },
  conteudo: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 60, gap: 16 },

  regar: { borderRadius: 24, borderWidth: 2, padding: 16, gap: 12 },
  regarTopo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  regarIcone: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  regarTitulo: { fontFamily: typography.bold, fontSize: 17, color: colors.primaryDark },
  regarSub: { fontFamily: typography.regular, fontSize: 13, lineHeight: 18, color: '#4B5B54', marginTop: 2 },
  acoesRegar: { flexDirection: 'row', gap: 10 },
  acaoRegar: { flex: 1, alignItems: 'center', gap: 6, paddingVertical: 12, borderRadius: 16, backgroundColor: colors.white, borderWidth: 2, borderColor: '#DDE3DF', borderBottomWidth: 4 },
  acaoRegarIcone: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  acaoRegarTexto: { fontFamily: typography.bold, fontSize: 13, color: colors.primaryDark },
  passos: { gap: 10, paddingTop: 2 },
  passoLinha: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  passoNumero: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.primaryDark, alignItems: 'center', justifyContent: 'center', marginTop: 1 },
  passoNumeroTexto: { fontFamily: typography.bold, fontSize: 12, color: colors.white },
  passoTexto: { flex: 1, fontFamily: typography.regular, fontSize: 13, lineHeight: 19, color: '#3F4F48' },

  msgCaixa: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, backgroundColor: '#EAF5DD', borderRadius: 14, padding: 12 },
  msgTexto: { flex: 1, fontFamily: typography.semiBold, fontSize: 13, lineHeight: 18, color: colors.primaryDark },

  cartao: { backgroundColor: colors.white, borderRadius: 24, borderWidth: 2, borderColor: '#E4E9E6', overflow: 'hidden' },
  palco: { alignItems: 'center', justifyContent: 'flex-end', paddingTop: 44, minHeight: 300, overflow: 'hidden' },
  grama: { position: 'absolute', left: -20, right: -20, bottom: -26, height: 52, borderRadius: 60, backgroundColor: '#A8DC73', opacity: 0.55 },
  chipEstagio: { position: 'absolute', top: 12, left: 12, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.92)', borderRadius: 16, paddingHorizontal: 10, paddingVertical: 6, zIndex: 2 },
  chipEstagioTexto: { fontFamily: typography.bold, fontSize: 12, color: colors.primaryDark },
  chipPontos: { position: 'absolute', top: 12, right: 12, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(255,255,255,0.92)', borderRadius: 16, paddingHorizontal: 10, paddingVertical: 6, zIndex: 2 },
  chipPontosTexto: { fontFamily: typography.bold, fontSize: 12, color: colors.primaryDark },
  gotas: { position: 'absolute', top: 54, alignSelf: 'center', width: 96, height: 90, zIndex: 3 },
  cresceu: { position: 'absolute', left: 14, right: 14, bottom: 14, zIndex: 4, backgroundColor: colors.primary, borderRadius: 16, borderBottomWidth: 4, borderBottomColor: colors.primaryShadow },
  cresceuLinha: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 14, paddingVertical: 12, minHeight: 48 },
  cresceuTexto: { flex: 1, fontFamily: typography.bold, fontSize: 14, color: colors.primaryDark },

  corpoCartao: { padding: 16, gap: 10 },
  tituloLinha: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', gap: 8 },
  tituloCartao: { fontFamily: typography.bold, fontSize: 17, color: colors.primaryDark },
  estagioNumero: { fontFamily: typography.semiBold, fontSize: 12, color: '#7A8B94' },
  barraFundo: { height: 12, borderRadius: 6, backgroundColor: '#F2F4F3', overflow: 'hidden' },
  barraCheia: { height: '100%', borderRadius: 6, backgroundColor: colors.primary },
  sub: { fontFamily: typography.regular, fontSize: 13, lineHeight: 19, color: '#5A6B64' },
  destaque: { fontFamily: typography.bold, fontSize: 13, color: colors.primaryDark },
  divisor: { height: 1, backgroundColor: '#EEF1EE', marginVertical: 4 },

  linhaTempo: { gap: 8, paddingVertical: 4, paddingRight: 8 },
  passo: { width: 76, alignItems: 'center', gap: 2, paddingVertical: 6, borderRadius: 14, borderWidth: 2, borderColor: 'transparent' },
  passoAtual: { borderColor: colors.primary, backgroundColor: '#F3FAEA' },
  passoNome: { fontFamily: typography.semiBold, fontSize: 10, color: colors.primaryDark, textAlign: 'center' },

  membros: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, marginVertical: 4 },
  membro: { alignItems: 'center', width: 60, gap: 2 },
  nomeMembro: { fontFamily: typography.semiBold, fontSize: 12, color: colors.primaryDark },
  chegando: { fontFamily: typography.regular, fontSize: 10, color: '#7A8B94' },
  gota: { position: 'absolute', right: -2, bottom: -2, width: 20, height: 20, borderRadius: 10, backgroundColor: AZUL_AGUA, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.white },
  rotulo: { fontFamily: typography.bold, fontSize: 14, color: colors.primaryDark },
  amigoLinha: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 52, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, backgroundColor: '#F8FAF8', borderWidth: 1, borderColor: '#EEF1EE' },
  acoesCartao: { gap: 10, marginTop: 4 },
  confirma: { gap: 10, padding: 14, borderRadius: 18, backgroundColor: '#FFF6F4', borderWidth: 1, borderColor: '#F6D5D0' },
  confirmaBotoes: { flexDirection: 'row', gap: 10 },

  cartaoConvite: { backgroundColor: colors.white, borderRadius: 22, padding: 14, borderWidth: 2, gap: 14 },
  conviteTopo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  conviteCeu: { width: 76, height: 76, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  vazio: { alignItems: 'center', gap: 8, paddingVertical: 12, paddingHorizontal: 8 },
  cartaoEscolha: { backgroundColor: colors.white, borderRadius: 24, padding: 16, gap: 14, borderWidth: 2, borderColor: '#E4E9E6' },
  temas: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  tema: { width: '47.5%', borderRadius: 18, borderWidth: 2, borderBottomWidth: 4, borderColor: '#E4E9E6', overflow: 'hidden', paddingBottom: 10, alignItems: 'center', gap: 2, backgroundColor: colors.white },
  temaCeu: { width: '100%', alignItems: 'center', paddingTop: 8 },
  temaNome: { fontFamily: typography.bold, fontSize: 14, color: colors.primaryDark, marginTop: 6 },
  temaDescricao: { fontFamily: typography.regular, fontSize: 11, lineHeight: 15, color: '#5A6B64', textAlign: 'center', paddingHorizontal: 8 },
});
