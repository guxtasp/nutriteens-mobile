// src/features/adolescente/social/screens/DesafioGrupoScreen.tsx
//
// Desafio em grupo: 2 a 5 amigos, 7 dias, um hábito medido contra a meta PESSOAL de cada um.
// Cooperativo por padrão (barra única da turma, marcos bronze/prata/ouro). Pódio é opcional (PodioTurma), vale por DIAS
// CUMPRIDOS (empate divide o degrau) e vem avisado no convite. Nunca mostra quem faltou (ver utils/desafioGrupo.ts).
// Ao acabar, "jogar de novo com a turma" cria o próximo desafio e convida os mesmos amigos com um toque.
// Confirmações usam painéis dentro da tela (Alert.alert com botões não funciona na web).
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppText } from '../../../../shared/ui/AppText';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import { useAuth } from '../../../../shared/contexts/AuthContext';
import { formatarDataISO } from '../../../../shared/utils/data';
import { feedbackConquista, feedbackToque } from '../../../../shared/audio/feedback';
import { AvatarSocialView } from '../components/AvatarSocialView';
import JardimBotao from '../components/JardimBotao';
import PodioTurma from '../components/PodioTurma';
import TrofeuCard from '../components/TrofeuCard';
import TrofeusTemporada from '../components/TrofeusTemporada';
import { trofeuDoDesafio, type Trofeu } from '../utils/trofeu';
import { ATIVIDADE } from '../theme/turma';
import { listarAmigos, type AmigoSocial } from '../services/socialService';
import {
  convidarParaDesafio, criarDesafio, listarDesafios, listarTrofeus, renovarDesafio, responderConviteDesafio, sairDoDesafio,
  sincronizarDesafiosHoje,
} from '../services/desafioGrupoService';
import { ehErroRestricaoSocial } from '../utils/moderacao';
import {
  DIAS_DESAFIO, MARCOS, MAX_DESAFIOS_ATIVOS, METRICAS_DESAFIO, ativosDoDesafio, diasRestantes, ehErroLimiteDesafio, fraseDaMetrica,
  jaAcabou, marcoAtingido, mensagemConviteDesafio, nomeDaMetrica, podeConvidar, proximoMarco, textoDoDia,
  type DesafioGrupo, type MarcoDesafio, type MetricaDesafio, type ModoDesafio,
} from '../utils/desafioGrupo';

const ROXO = ATIVIDADE.desafio.cor;
const COR_MARCO: Record<MarcoDesafio, string> = { NENHUM: '#D5DCD8', BRONZE: '#C98A4B', PRATA: '#9AA7B0', OURO: '#F2B705' };
const ROTA_REGISTRO: Record<MetricaDesafio, 'ConsumoAgua' | 'AtividadeFisica' | 'TipoRefeicao'> = {
  AGUA: 'ConsumoAgua', ATIVIDADE: 'AtividadeFisica', PASSOS: 'AtividadeFisica', REGISTRO: 'TipoRefeicao',
};

function mensagemErro(e: unknown): string {
  if (ehErroRestricaoSocial(e)) return 'Seu espaço de amigos está em pausa por enquanto. Seus hábitos continuam contando nos desafios que você já faz.';
  if (ehErroLimiteDesafio(e)) return `Você já está em ${MAX_DESAFIOS_ATIVOS} desafios. Termine ou saia de um para criar outro.`;
  return 'Algo deu errado. Tente de novo daqui a pouco.';
}

function diasDoDesafio(inicio: string): string[] {
  const base = new Date(`${inicio}T00:00:00`);
  return Array.from({ length: DIAS_DESAFIO }, (_, i) => {
    const d = new Date(base);
    d.setDate(base.getDate() + i);
    return formatarDataISO(d);
  });
}

const LETRAS = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
const letraDoDia = (iso: string) => LETRAS[new Date(`${iso}T00:00:00`).getDay()];

function BarraTurma({ total, ativos }: { total: number; ativos: number }) {
  const maximo = Math.max(1, ativos * DIAS_DESAFIO);
  const fracao = Math.min(1, total / maximo);
  const marco = marcoAtingido(total, ativos);
  const prox = proximoMarco(total, ativos);
  return (
    <View style={estilos.bloco}>
      <View style={estilos.linhaEntre}>
        <AppText style={estilos.rotulo}>Barra da turma</AppText>
        <AppText style={[estilos.chipMarco, { backgroundColor: COR_MARCO[marco] }]}>{marco === 'NENHUM' ? 'A caminho do bronze' : `Marco ${MARCOS.find((m) => m.marco === marco)?.nome}`}</AppText>
      </View>
      <View style={estilos.trilho} accessible accessibilityLabel={`A turma já cumpriu ${total} de ${maximo} dias possíveis`}>
        <View style={[estilos.preenchido, { width: `${Math.max(3, Math.round(fracao * 100))}%`, backgroundColor: COR_MARCO[marco === 'NENHUM' ? 'BRONZE' : marco] }]} />
        {MARCOS.map((m) => (
          <View key={m.marco} style={[estilos.marcador, { left: `${Math.min(99, Math.round(((m.diasPorPessoa * ativos) / maximo) * 100))}%`, backgroundColor: total >= m.diasPorPessoa * ativos ? COR_MARCO[m.marco] : colors.white, borderColor: COR_MARCO[m.marco] }]} />
        ))}
      </View>
      <AppText style={estilos.sub}>
        {prox ? `Faltam ${prox.faltam} ${prox.faltam === 1 ? 'dia' : 'dias'} da turma para o ${prox.nome.toLowerCase()}.` : 'A turma chegou ao ouro! Mandou muito bem.'}
      </AppText>
    </View>
  );
}

function FaixaDias({ d, hoje }: { d: DesafioGrupo; hoje: string }) {
  const feitos = new Set(d.meusDias);
  return (
    <View style={estilos.faixa}>
      {diasDoDesafio(d.inicio).map((iso) => {
        const feito = feitos.has(iso);
        const ehHoje = iso === hoje;
        const futuro = iso > hoje;
        return (
          <View key={iso} style={estilos.diaCol} accessible accessibilityLabel={`${iso}${feito ? ', cumprido' : ehHoje ? ', hoje' : ''}`}>
            <View style={[estilos.diaBolinha, feito && { backgroundColor: colors.primary, borderColor: colors.primary }, ehHoje && !feito && { borderColor: ROXO, borderWidth: 2 }, futuro && { opacity: 0.45 }]}>
              {feito && <Ionicons name="checkmark" size={16} color={colors.primaryDark} />}
            </View>
            <AppText style={[estilos.diaLetra, ehHoje && { color: ROXO }]}>{letraDoDia(iso)}</AppText>
          </View>
        );
      })}
    </View>
  );
}

function CartaoDesafio({ d, amigos, hoje, aoMudar }: { d: DesafioGrupo; amigos: AmigoSocial[]; hoje: string; aoMudar: () => void }) {
  const navigation = useNavigation<any>();
  const ativos = ativosDoDesafio(d);
  const eu = ativos.find((m) => m.eu);
  const acabou = jaAcabou(d, hoje);
  const resta = diasRestantes(d.fim, hoje);
  const marco = marcoAtingido(d.totalDias, ativos.length);
  const [convidando, setConvidando] = useState(false);
  const [saindo, setSaindo] = useState(false);
  const [ocupado, setOcupado] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [subiu, setSubiu] = useState<string | null>(null);
  const nomes = new Set(d.membros.map((m) => m.apelido));
  const disponiveis = amigos.filter((a) => !nomes.has(a.apelido));

  // lembra o maior marco visto neste aparelho; se subiu, comemora
  useEffect(() => {
    if (acabou) return;
    let vivo = true;
    const chave = `desafio:marco:${d.id}`;
    const ordem: MarcoDesafio[] = ['NENHUM', 'BRONZE', 'PRATA', 'OURO'];
    AsyncStorage.getItem(chave).then((v) => {
      if (!vivo) return;
      const antes = ordem.indexOf((v as MarcoDesafio) ?? 'NENHUM');
      if (v !== null && ordem.indexOf(marco) > antes) {
        setSubiu(`A turma chegou ao ${MARCOS.find((m) => m.marco === marco)?.nome.toLowerCase()}!`);
        feedbackConquista();
      }
      if (ordem.indexOf(marco) > Math.max(0, antes) || v === null) void AsyncStorage.setItem(chave, marco).catch(() => undefined);
    }).catch(() => undefined);
    return () => { vivo = false; };
  }, [d.id, marco, acabou]);

  async function executar(f: () => Promise<void>) {
    feedbackToque();
    setOcupado(true);
    try { await f(); } catch (e) { setMsg(mensagemErro(e)); } finally { setOcupado(false); }
  }

  return (
    <View style={estilos.cartao}>
      <View style={estilos.cartaoTopo}>
        <View style={estilos.iconeMetrica}><Ionicons name={(METRICAS_DESAFIO.find((m) => m.metrica === d.metrica)?.icone ?? 'flag') as any} size={22} color={colors.white} /></View>
        <View style={{ flex: 1 }}>
          <AppText style={estilos.tituloCartao}>{nomeDaMetrica(d.metrica)}</AppText>
          <AppText style={estilos.sub}>{fraseDaMetrica(d.metrica)} {d.modo === 'PODIO' ? '· com pódio' : '· em equipe'}</AppText>
        </View>
        <View style={[estilos.chipTempo, acabou && { backgroundColor: '#E8F3DC' }]}>
          <AppText style={estilos.chipTempoTexto}>{acabou ? 'Acabou' : resta <= 0 ? 'Último dia' : `${resta} ${resta === 1 ? 'dia' : 'dias'}`}</AppText>
        </View>
      </View>

      {!!subiu && (
        <Pressable onPress={() => setSubiu(null)} accessibilityRole="button" accessibilityLabel={`${subiu} Toque para fechar.`} style={estilos.subiu}>
          <Ionicons name="sparkles" size={18} color={colors.primaryDark} />
          <AppText style={estilos.subiuTexto}>{subiu}</AppText>
        </Pressable>
      )}

      <BarraTurma total={d.totalDias} ativos={ativos.length} />
      <FaixaDias d={d} hoje={hoje} />
      {!acabou && <AppText style={estilos.destaque}>{textoDoDia(d)}</AppText>}
      <PodioTurma d={d} acabou={acabou} />
      {(() => { const t = trofeuDoDesafio(d, acabou); return t ? <TrofeuCard trofeu={t} /> : null; })()}

      <View style={estilos.membros}>
        {d.membros.map((m) => (
          <View key={m.apelido + (m.eu ? 'eu' : '')} style={[estilos.membro, m.pendente && { opacity: 0.5 }]} accessible accessibilityLabel={`${m.eu ? 'Você' : m.apelido}${m.pendente ? ', convite enviado' : m.fezHoje ? ', cumpriu hoje' : ''}`}>
            <View>
              <AvatarSocialView avatar={m.avatar} size="small" />
              {m.fezHoje && !m.pendente && <View style={estilos.check}><Ionicons name="checkmark" size={12} color={colors.white} /></View>}
            </View>
            <AppText style={estilos.nomeMembro} numberOfLines={1}>{m.eu ? 'Você' : m.apelido}</AppText>
            {m.pendente && <AppText style={estilos.miudo}>convidado</AppText>}
          </View>
        ))}
      </View>

      {acabou ? (
        <View style={estilos.fim}>
          <AppText style={estilos.sub}>
            {marco === 'OURO' ? 'Ouro! Você ganhou as insígnias “Na turma” e “Turma de ouro”.' : 'Você ganhou a insígnia “Na turma”. Cada dia cumprido contou para a turma.'}
          </AppText>
          <JardimBotao icone="refresh" label="JOGAR DE NOVO COM A TURMA" carregando={ocupado}
            onPress={() => void executar(async () => { await renovarDesafio(d.id); aoMudar(); })} />
        </View>
      ) : (
        <>
          {eu && !eu.fezHoje && (
            <JardimBotao variante="primario" icone="flash" label="CUMPRIR HOJE" onPress={() => navigation.navigate(ROTA_REGISTRO[d.metrica])} />
          )}
          {!!msg && (
            <View style={estilos.msgCaixa} accessibilityRole="alert">
              <Ionicons name="information-circle" size={18} color={colors.primaryDark} />
              <AppText style={estilos.msgTexto}>{msg}</AppText>
            </View>
          )}
          {podeConvidar(d, hoje) && (convidando ? (
            <View style={estilos.bloco}>
              <AppText style={estilos.rotulo}>Quem você quer chamar?</AppText>
              {disponiveis.length === 0 ? <AppText style={estilos.sub}>Todos os seus amigos já estão aqui ou foram convidados.</AppText> : disponiveis.map((a) => (
                <Pressable key={a.amizadeId} disabled={ocupado} accessibilityRole="button" accessibilityLabel={`Convidar ${a.apelido}`}
                  onPress={() => void executar(async () => {
                    const r = await convidarParaDesafio(d.id, a.amizadeId);
                    setMsg(mensagemConviteDesafio(r, a.apelido));
                    if (r === 'enviado') { setConvidando(false); aoMudar(); }
                  })}
                  style={({ pressed }) => [estilos.amigo, pressed && { opacity: 0.7 }]}>
                  <AvatarSocialView avatar={a.avatar} size="small" />
                  <AppText style={estilos.nomePodio} numberOfLines={1}>{a.apelido}</AppText>
                  <Ionicons name="paper-plane" size={18} color={ROXO} />
                </Pressable>
              ))}
              <JardimBotao variante="texto" tamanho="pequeno" label="FECHAR" onPress={() => setConvidando(false)} />
            </View>
          ) : (
            <JardimBotao variante="suave" icone="person-add" label="CHAMAR UM AMIGO" onPress={() => { setMsg(null); setConvidando(true); }} />
          ))}
          {saindo ? (
            <View style={estilos.bloco}>
              <AppText style={estilos.sub}>Sair do desafio? Os dias que você já cumpriu continuam valendo para a turma.</AppText>
              <View style={estilos.botoesLinha}>
                <View style={{ flex: 1 }}><JardimBotao variante="contorno" label="FICAR" onPress={() => setSaindo(false)} /></View>
                <View style={{ flex: 1 }}><JardimBotao variante="perigo" label="SAIR" carregando={ocupado} onPress={() => void executar(async () => { await sairDoDesafio(d.id); aoMudar(); })} /></View>
              </View>
            </View>
          ) : (
            <JardimBotao variante="texto" tamanho="pequeno" label="Sair do desafio" onPress={() => setSaindo(true)} />
          )}
        </>
      )}
    </View>
  );
}

export default function DesafioGrupoScreen() {
  const navigation = useNavigation<any>();
  const { userId } = useAuth();
  const hoje = formatarDataISO(new Date());
  const [desafios, setDesafios] = useState<DesafioGrupo[]>([]);
  const [trofeus, setTrofeus] = useState<Trofeu[]>([]);
  const [amigos, setAmigos] = useState<AmigoSocial[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [criando, setCriando] = useState(false);
  const [metrica, setMetrica] = useState<MetricaDesafio>('AGUA');
  const [modo, setModo] = useState<ModoDesafio>('COOPERATIVO');
  const [ocupado, setOcupado] = useState(false);
  const [aviso, setAviso] = useState<string | null>(null);

  const carregar = useCallback(async () => {
    try {
      // marca o dia de hoje se a meta já foi batida (registrou antes de criar o desafio, ou a Home ainda não abriu)
      if (userId) await sincronizarDesafiosHoje(userId, hoje);
      const [ds, am, tr] = await Promise.all([listarDesafios(), listarAmigos().catch(() => [] as AmigoSocial[]), listarTrofeus().catch(() => [] as Trofeu[])]);
      setDesafios(ds);
      setTrofeus(tr);
      setAmigos(am);
      setErro(null);
    } catch {
      setErro('Não deu para carregar seus desafios agora.');
    } finally {
      setCarregando(false);
    }
  }, [userId, hoje]);

  useFocusEffect(useCallback(() => { void carregar(); }, [carregar]));

  const convites = desafios.filter((d) => d.situacao === 'convidado');
  const ativos = desafios.filter((d) => d.situacao === 'ativo' && !jaAcabou(d, hoje));
  const acabados = desafios.filter((d) => d.situacao === 'ativo' && jaAcabou(d, hoje));

  function voltar() {
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.navigate('Social');
  }

  async function criar() {
    feedbackToque();
    setAviso(null);
    setOcupado(true);
    try {
      await criarDesafio(metrica, modo);
      setCriando(false);
      await carregar();
    } catch (e) {
      setAviso(mensagemErro(e));
    } finally {
      setOcupado(false);
    }
  }

  async function responder(d: DesafioGrupo, aceitar: boolean) {
    feedbackToque();
    setAviso(null);
    setOcupado(true);
    try {
      const ok = await responderConviteDesafio(d.id, aceitar);
      if (!ok && aceitar) setAviso('Não deu para entrar: o desafio encheu, o prazo de entrada passou ou você já está em 3 desafios.');
      await carregar();
    } catch (e) {
      setAviso(mensagemErro(e));
    } finally {
      setOcupado(false);
    }
  }

  return (
    <SafeAreaView style={estilos.tela} edges={['top']}>
      <View style={estilos.header}>
        <Pressable onPress={voltar} style={estilos.voltar} accessibilityRole="button" accessibilityLabel="Voltar" hitSlop={8}>
          <Ionicons name="arrow-back" size={22} color={colors.primaryDark} />
        </Pressable>
        <AppText style={estilos.titulo}>Desafio em grupo</AppText>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={estilos.conteudo} showsVerticalScrollIndicator={false}>
        {!!aviso && (
          <View style={estilos.msgCaixa} accessibilityRole="alert">
            <Ionicons name="information-circle" size={18} color={colors.primaryDark} />
            <AppText style={estilos.msgTexto}>{aviso}</AppText>
          </View>
        )}

        {carregando ? <ActivityIndicator color={colors.primaryDark} style={{ marginTop: 40 }} /> : erro ? (
          <View style={{ alignItems: 'center', gap: 12, marginTop: 30 }}>
            <AppText style={estilos.sub}>{erro}</AppText>
            <JardimBotao bloco={false} icone="refresh" label="TENTAR DE NOVO" onPress={() => { setCarregando(true); void carregar(); }} />
          </View>
        ) : (
          <>
            {convites.map((d) => (
              <View key={d.id} style={[estilos.cartao, { borderColor: ROXO }]}>
                <AppText style={estilos.tituloCartao}>{d.convidadoPor ?? 'Um amigo'} te chamou para “{nomeDaMetrica(d.metrica)}”</AppText>
                <AppText style={estilos.sub}>{fraseDaMetrica(d.metrica)} por 7 dias, cada um na sua meta. {d.modo === 'PODIO' ? 'Este desafio tem pódio por dias cumpridos.' : 'Aqui todo mundo joga junto, sem ranking.'}</AppText>
                <View style={estilos.botoesLinha}>
                  <View style={{ flex: 1 }}><JardimBotao variante="contorno" label="AGORA NÃO" onPress={() => void responder(d, false)} desabilitado={ocupado} /></View>
                  <View style={{ flex: 1 }}><JardimBotao variante="primario" icone="checkmark" label="ENTRAR" onPress={() => void responder(d, true)} carregando={ocupado} /></View>
                </View>
              </View>
            ))}

            {ativos.map((d) => <CartaoDesafio key={d.id} d={d} amigos={amigos} hoje={hoje} aoMudar={carregar} />)}
            {acabados.map((d) => <CartaoDesafio key={d.id} d={d} amigos={amigos} hoje={hoje} aoMudar={carregar} />)}

            {ativos.length === 0 && acabados.length === 0 && convites.length === 0 && (
              <View style={estilos.vazio}>
                <View style={[estilos.iconeMetrica, { width: 72, height: 72, borderRadius: 36 }]}><Ionicons name="people" size={34} color={colors.white} /></View>
                <AppText style={estilos.tituloCartao}>Monte uma turma</AppText>
                <AppText style={[estilos.sub, { textAlign: 'center' }]}>Escolham um hábito e cumpram juntos por 7 dias, cada um na sua meta. A barra da turma sobe com o dia de todo mundo e vocês ganham insígnias.</AppText>
              </View>
            )}

            {ativos.length < MAX_DESAFIOS_ATIVOS && (criando ? (
              <View style={estilos.cartao}>
                <AppText style={estilos.tituloCartao}>Qual hábito a turma vai cumprir?</AppText>
                {METRICAS_DESAFIO.map((m) => (
                  <Pressable key={m.metrica} onPress={() => setMetrica(m.metrica)} accessibilityRole="radio" accessibilityState={{ selected: metrica === m.metrica }}
                    style={[estilos.opcao, metrica === m.metrica && estilos.opcaoMarcada]}>
                    <Ionicons name={m.icone as any} size={22} color={metrica === m.metrica ? ROXO : '#7A8A83'} />
                    <View style={{ flex: 1 }}>
                      <AppText style={estilos.nomePodio}>{m.nome}</AppText>
                      <AppText style={estilos.miudo}>{m.frase}</AppText>
                    </View>
                    {metrica === m.metrica && <Ionicons name="checkmark-circle" size={22} color={ROXO} />}
                  </Pressable>
                ))}
                <AppText style={[estilos.rotulo, { marginTop: 6 }]}>Como vai ser?</AppText>
                {([['COOPERATIVO', 'Em equipe', 'Só a barra da turma. Sem ranking.'], ['PODIO', 'Com pódio', 'Mostra quem cumpriu mais dias. Quem entrar sabe disso.']] as const).map(([v, nome, desc]) => (
                  <Pressable key={v} onPress={() => setModo(v)} accessibilityRole="radio" accessibilityState={{ selected: modo === v }}
                    style={[estilos.opcao, modo === v && estilos.opcaoMarcada]}>
                    <Ionicons name={v === 'PODIO' ? 'trophy' : 'people'} size={22} color={modo === v ? ROXO : '#7A8A83'} />
                    <View style={{ flex: 1 }}>
                      <AppText style={estilos.nomePodio}>{nome}</AppText>
                      <AppText style={estilos.miudo}>{desc}</AppText>
                    </View>
                    {modo === v && <Ionicons name="checkmark-circle" size={22} color={ROXO} />}
                  </Pressable>
                ))}
                <AppText style={estilos.miudo}>Vale sempre a meta de cada um, então ninguém precisa fazer mais que o seu. Depois de criar, chame os amigos nos 2 primeiros dias.</AppText>
                <JardimBotao icone="flag" label="COMEÇAR DESAFIO" carregando={ocupado} onPress={() => void criar()} />
                <JardimBotao variante="contorno" label="CANCELAR" onPress={() => setCriando(false)} />
              </View>
            ) : (
              <JardimBotao variante={ativos.length === 0 && acabados.length === 0 ? 'primario' : 'suave'} icone="add" label="NOVO DESAFIO" onPress={() => { setAviso(null); setCriando(true); }} />
            ))}

            <TrofeusTemporada trofeus={trofeus} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#F6F8F5' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingVertical: 8 },
  voltar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.white },
  titulo: { fontFamily: typography.bold, fontSize: 18, color: colors.primaryDark },
  conteudo: { padding: 16, gap: 14, paddingBottom: 48 },
  cartao: { backgroundColor: colors.white, borderRadius: 22, borderWidth: 1, borderColor: '#E4E9E6', padding: 16, gap: 12 },
  cartaoTopo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconeMetrica: { width: 44, height: 44, borderRadius: 22, backgroundColor: ROXO, alignItems: 'center', justifyContent: 'center' },
  tituloCartao: { fontFamily: typography.bold, fontSize: 16, lineHeight: 21, color: colors.primaryDark },
  sub: { fontFamily: typography.regular, fontSize: 13, lineHeight: 18, color: '#4B5B54' },
  miudo: { fontFamily: typography.regular, fontSize: 12, lineHeight: 16, color: '#6B7B74' },
  rotulo: { fontFamily: typography.bold, fontSize: 11, letterSpacing: 0.8, color: '#5A6B64', textTransform: 'uppercase' },
  destaque: { fontFamily: typography.bold, fontSize: 13.5, color: ROXO },
  chipTempo: { paddingHorizontal: 10, height: 28, borderRadius: 14, backgroundColor: '#F1ECFD', alignItems: 'center', justifyContent: 'center' },
  chipTempoTexto: { fontFamily: typography.bold, fontSize: 12, color: ROXO },
  chipMarco: { fontFamily: typography.bold, fontSize: 11, color: colors.white, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 10, overflow: 'hidden' },
  linhaEntre: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  bloco: { gap: 8 },
  trilho: { height: 16, borderRadius: 8, backgroundColor: '#EEF2EF', justifyContent: 'center' },
  preenchido: { height: 16, borderRadius: 8 },
  marcador: { position: 'absolute', width: 14, height: 14, borderRadius: 7, borderWidth: 2, marginLeft: -7, top: 1 },
  faixa: { flexDirection: 'row', justifyContent: 'space-between' },
  diaCol: { alignItems: 'center', gap: 4 },
  diaBolinha: { width: 34, height: 34, borderRadius: 17, borderWidth: 1.5, borderColor: '#D5DCD8', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.white },
  diaLetra: { fontFamily: typography.bold, fontSize: 11, color: '#8A9A92' },
  nomePodio: { flex: 1, fontFamily: typography.bold, fontSize: 14, color: colors.primaryDark },
  membros: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  membro: { alignItems: 'center', gap: 3, width: 58 },
  nomeMembro: { fontFamily: typography.regular, fontSize: 11.5, color: '#4B5B54', maxWidth: 58 },
  check: { position: 'absolute', right: -4, bottom: -2, width: 18, height: 18, borderRadius: 9, backgroundColor: '#3E8E2F', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.white },
  subiu: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 14, backgroundColor: '#EAF5DD' },
  subiuTexto: { flex: 1, fontFamily: typography.bold, fontSize: 13, color: colors.primaryDark },
  fim: { gap: 10 },
  amigo: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8 },
  botoesLinha: { flexDirection: 'row', gap: 10 },
  msgCaixa: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderRadius: 14, backgroundColor: '#EAF5DD' },
  msgTexto: { flex: 1, fontFamily: typography.regular, fontSize: 13, lineHeight: 18, color: colors.primaryDark },
  vazio: { alignItems: 'center', gap: 10, paddingVertical: 24 },
  opcao: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, minHeight: 56, borderRadius: 16, borderWidth: 1.5, borderColor: '#E4E9E6' },
  opcaoMarcada: { borderColor: ROXO, backgroundColor: '#F7F4FE' },
});
