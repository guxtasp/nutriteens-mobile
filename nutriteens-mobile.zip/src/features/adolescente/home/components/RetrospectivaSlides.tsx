// src/features/adolescente/home/components/RetrospectivaSlides.tsx
//
// "Seu ano com o Bróxis" em slides animados, no estilo das retrospectivas de fim de ano:
// toque na direita (ou "Continuar") avança, toque na esquerda volta. O último slide é um
// CARTÃO que parabeniza, resume o que a pessoa conquistou e apresenta o NutriTeens — é ele que
// vira imagem no "Compartilhar" (ver services/compartilharRetrospectiva.ts).
// Só celebra: sem nota, sem comparação, sem dado pessoal no cartão.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, TouchableOpacity, View } from 'react-native';
import { MotiView } from 'moti';
import { Ionicons } from '@expo/vector-icons';
import { AppButton } from '../../../../shared/ui/AppButton';
import { AppText } from '../../../../shared/ui/AppText';
import { BroxisMascot } from '../../../../shared/ui/BroxisMascot';
import { colors } from '../../../../shared/theme/colors';
import { typography } from '../../../../shared/theme/typography';
import { feedbackSelecao } from '../../../../shared/audio/feedback';
import { ACENTOS } from '../../metricas/ui/tokens';
import type { IconeMomento, RetrospectivaAno, SlideAno } from '../../metricas/utils/retrospectivaSlides';
import { compartilharRetrospectiva } from '../services/compartilharRetrospectiva';

type Props = {
  retrospectiva: RetrospectivaAno;
  reduzirMovimento: boolean;
  onFechar: () => void;
};

const ICONE_MOMENTO: Record<IconeMomento, React.ComponentProps<typeof Ionicons>['name']> = {
  calendar: 'calendar',
  flame: 'flame',
  sparkles: 'sparkles',
};

/** Número que "sobe" até o valor; com movimento reduzido já mostra o valor final. */
function Contador({ valor, parado }: { valor: number; parado: boolean }) {
  const [n, setN] = useState(parado ? valor : 0);

  useEffect(() => {
    if (parado) {
      setN(valor);
      return;
    }
    const anim = new Animated.Value(0);
    const id = anim.addListener(({ value }) => setN(Math.round(value)));
    Animated.timing(anim, {
      toValue: valor,
      duration: Math.min(1500, 600 + valor * 6),
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false, // anima um número em texto: precisa do thread JS
    }).start();
    return () => {
      anim.removeListener(id);
      anim.stopAnimation();
    };
  }, [valor, parado]);

  return (
    <AppText style={styles.numeroGrande} accessibilityLabel={String(valor)}>
      {n}
    </AppText>
  );
}

function descricaoAcessivel(slide: SlideAno): string {
  switch (slide.tipo) {
    case 'intro':
      return `${slide.titulo}. ${slide.periodo}. ${slide.texto}`;
    case 'numero':
      return `${slide.valor} ${slide.rotulo}. ${slide.frase}`;
    case 'momento':
      return `${slide.titulo}: ${slide.destaque}. ${slide.frase}`;
    case 'final':
      return `${slide.titulo} ${slide.resumo.map((r) => `${r.valor} ${r.rotulo}`).join(', ')}. ${slide.mensagem}`;
  }
}

export default function RetrospectivaSlides({ retrospectiva, reduzirMovimento, onFechar }: Props) {
  const { slides, textoCompartilhar } = retrospectiva;
  const [indice, setIndice] = useState(0);
  const [compartilhando, setCompartilhando] = useState(false);
  const cartaoRef = useRef<View>(null);

  const slide = slides[indice];
  const ultimo = indice === slides.length - 1;

  const avancar = useCallback(() => {
    setIndice((i) => {
      if (i >= slides.length - 1) return i;
      feedbackSelecao();
      return i + 1;
    });
  }, [slides.length]);

  const voltar = useCallback(() => {
    setIndice((i) => {
      if (i <= 0) return i;
      feedbackSelecao();
      return i - 1;
    });
  }, []);

  async function aoCompartilhar() {
    if (compartilhando) return;
    setCompartilhando(true);
    try {
      await compartilharRetrospectiva({ texto: textoCompartilhar, cartaoRef: cartaoRef.current });
    } finally {
      setCompartilhando(false);
    }
  }

  const entrada = reduzirMovimento
    ? { from: { opacity: 0 }, animate: { opacity: 1 } }
    : { from: { opacity: 0, translateY: 24 }, animate: { opacity: 1, translateY: 0 } };

  return (
    <View style={styles.raiz}>
      {/* progresso (um segmento por slide) + fechar */}
      <View style={styles.topo}>
        <View style={styles.progresso} accessibilityLabel={`Slide ${indice + 1} de ${slides.length}`}>
          {slides.map((_, i) => (
            <View key={i} style={[styles.segmento, i <= indice && styles.segmentoCheio]} />
          ))}
        </View>
        <TouchableOpacity onPress={onFechar} accessibilityRole="button" accessibilityLabel="Fechar" hitSlop={12}>
          <Ionicons name="close" size={24} color={colors.white} />
        </TouchableOpacity>
      </View>

      <View style={styles.area}>
        <MotiView
          key={indice}
          from={entrada.from}
          animate={entrada.animate}
          transition={{ type: 'timing', duration: reduzirMovimento ? 120 : 380 }}
          style={styles.slide}
          accessible
          accessibilityLabel={descricaoAcessivel(slide)}
        >
          {slide.tipo === 'intro' && (
            <>
              <BroxisMascot size={150} pose="supercontente" entrance={reduzirMovimento ? 'nenhuma' : 'pulo'} showParticles={false} />
              <AppText style={styles.kicker}>{slide.periodo}</AppText>
              <AppText style={styles.tituloGrande} accessibilityRole="header">{slide.titulo}</AppText>
              <AppText style={styles.frase}>{slide.texto}</AppText>
            </>
          )}

          {slide.tipo === 'numero' && (
            <>
              <View style={[styles.iconeCirculo, { backgroundColor: ACENTOS[slide.cartao].suave }]}>
                <Ionicons name={ACENTOS[slide.cartao].icone} size={30} color={ACENTOS[slide.cartao].cor} />
              </View>
              <Contador valor={slide.valor} parado={reduzirMovimento} />
              <AppText style={styles.rotuloGrande}>{slide.rotulo}</AppText>
              <AppText style={styles.frase}>{slide.frase}</AppText>
              <BroxisMascot size={110} pose="orgulhoso" entrance="nenhuma" showParticles={false} />
            </>
          )}

          {slide.tipo === 'momento' && (
            <>
              <View style={[styles.iconeCirculo, { backgroundColor: 'rgba(255,243,196,0.18)' }]}>
                <Ionicons name={ICONE_MOMENTO[slide.icone]} size={30} color="#FFF3C4" />
              </View>
              <AppText style={styles.kicker}>{slide.titulo}</AppText>
              <AppText style={styles.destaqueMomento}>{slide.destaque}</AppText>
              <AppText style={styles.frase}>{slide.frase}</AppText>
              <BroxisMascot size={110} pose="curioso" entrance="nenhuma" showParticles={false} />
            </>
          )}

          {slide.tipo === 'final' && (
            // este View vira a imagem compartilhada: fundo opaco, sem dado pessoal
            <View ref={cartaoRef} collapsable={false} style={styles.cartaoFinal}>
              <BroxisMascot size={96} pose="supercontente" entrance="nenhuma" showParticles={false} />
              <AppText style={styles.cartaoTitulo} accessibilityRole="header">{slide.titulo}</AppText>
              <View style={styles.cartaoLista}>
                {slide.resumo.map((r) => (
                  <View key={r.rotulo} style={styles.cartaoLinha}>
                    <AppText style={styles.cartaoValor}>{r.valor}</AppText>
                    <AppText style={styles.cartaoRotulo}>{r.rotulo}</AppText>
                  </View>
                ))}
              </View>
              <AppText style={styles.cartaoMensagem}>{slide.mensagem}</AppText>
              <View style={styles.cartaoRodape}>
                <AppText style={styles.cartaoMarca}>NutriTeens</AppText>
                <AppText style={styles.cartaoMarcaSub}>alimentação leve para adolescentes</AppText>
              </View>
            </View>
          )}
        </MotiView>

        {/* toque: esquerda volta, direita avança (no último slide ficam os botões) */}
        {!ultimo && (
          <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
            <View style={styles.zonas}>
              <Pressable style={styles.zonaVoltar} onPress={voltar} accessibilityLabel="Slide anterior" />
              <Pressable style={styles.zonaAvancar} onPress={avancar} accessibilityLabel="Próximo slide" />
            </View>
          </View>
        )}
      </View>

      <View style={styles.rodape}>
        {ultimo ? (
          <>
            <AppButton
              label={compartilhando ? 'Abrindo...' : 'Compartilhar minha conquista'}
              onPress={aoCompartilhar}
              disabled={compartilhando}
            />
            <TouchableOpacity onPress={onFechar} accessibilityRole="button" style={styles.linkFechar} hitSlop={8}>
              <AppText style={styles.linkFecharTexto}>Valeu, Bróxis!</AppText>
            </TouchableOpacity>
          </>
        ) : (
          <AppButton label={indice === 0 ? 'Vamos lá!' : 'Continuar'} onPress={avancar} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  raiz: { flex: 1, width: '100%' },
  topo: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  progresso: { flex: 1, flexDirection: 'row', gap: 4 },
  segmento: { flex: 1, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.25)' },
  segmentoCheio: { backgroundColor: colors.white },
  area: { flex: 1, justifyContent: 'center' },
  slide: { alignItems: 'center', gap: 10 },
  zonas: { flex: 1, flexDirection: 'row' },
  zonaVoltar: { flex: 3 },
  zonaAvancar: { flex: 7 },
  kicker: {
    fontFamily: typography.bold, fontSize: 13, letterSpacing: 0.8, color: '#FFF3C4',
    textAlign: 'center', textTransform: 'uppercase',
  },
  tituloGrande: { fontFamily: typography.bold, fontSize: 32, lineHeight: 38, color: colors.white, textAlign: 'center' },
  frase: {
    fontFamily: typography.regular, fontSize: 16, lineHeight: 22, color: colors.textOnDarkMuted,
    textAlign: 'center', paddingHorizontal: 8,
  },
  iconeCirculo: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  numeroGrande: { fontFamily: typography.bold, fontSize: 84, lineHeight: 92, color: colors.white, textAlign: 'center' },
  rotuloGrande: { fontFamily: typography.bold, fontSize: 22, color: colors.white, textAlign: 'center' },
  destaqueMomento: {
    fontFamily: typography.bold, fontSize: 46, lineHeight: 54, color: colors.white,
    textAlign: 'center', textTransform: 'capitalize',
  },
  cartaoFinal: {
    width: '100%', backgroundColor: colors.primaryDark, borderRadius: 24, padding: 20,
    alignItems: 'center', gap: 10,
  },
  cartaoTitulo: { fontFamily: typography.bold, fontSize: 24, lineHeight: 30, color: colors.white, textAlign: 'center' },
  cartaoLista: { width: '100%', gap: 8, marginTop: 4 },
  cartaoLinha: {
    flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(255,255,255,0.10)',
    borderRadius: 14, paddingVertical: 8, paddingHorizontal: 14,
  },
  cartaoValor: { fontFamily: typography.bold, fontSize: 28, color: colors.primary, minWidth: 56 },
  cartaoRotulo: { flex: 1, fontFamily: typography.semiBold, fontSize: 15, color: colors.white },
  cartaoMensagem: {
    fontFamily: typography.medium, fontSize: 14, lineHeight: 20, color: colors.textOnDarkMuted, textAlign: 'center',
  },
  cartaoRodape: { alignItems: 'center', marginTop: 4 },
  cartaoMarca: { fontFamily: typography.bold, fontSize: 18, color: colors.primary },
  cartaoMarcaSub: { fontFamily: typography.medium, fontSize: 12, color: colors.textOnDarkMuted },
  rodape: { width: '100%', gap: 10 },
  linkFechar: { alignItems: 'center', paddingVertical: 8 },
  linkFecharTexto: { fontFamily: typography.bold, fontSize: 15, color: colors.white },
});
