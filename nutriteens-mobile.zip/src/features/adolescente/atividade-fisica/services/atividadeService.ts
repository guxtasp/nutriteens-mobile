// src/features/adolescente/services/atividadeService.ts
import { supabase } from '../../../../lib/supabase';
import { obterOuCriarRegistroDiario } from '../../../../shared/services/registroDiarioService';
import { formatarDataISO } from '../../../../shared/utils/data';
import { registrarEvento } from '../../../../shared/analytics/analytics';
import { comCache } from '../../../../shared/offline/cacheLocal';

export type AtividadeCatalogo = {
  id: string;
  nome: string;
  duracao_padrao_min: number;
};

export type ItemParaRegistrar = {
  nomeAtividade: string;
  duracaoMinutos: number;
  /** HH:MM:SS em que o adolescente fez/registrou; sem isso, usa a hora do envio */
  horarioRegistro?: string;
};

function normalizar(texto: string): string {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove acentos
    .toLowerCase();
}

/** Busca no catálogo, com filtro opcional por termo (pesquisa, ignora acento) */
export async function buscarAtividades(termo: string = ''): Promise<AtividadeCatalogo[]> {
  // catálogo com cópia local: sem internet, a busca continua funcionando
  const todas = await comCache<AtividadeCatalogo[]>('atividades:catalogo', async () => {
    const { data, error } = await supabase
      .from('atividades')
      .select('id, nome, duracao_padrao_min')
      .order('nome');

    if (error) throw error;
    return data ?? [];
  });

  if (!termo.trim()) return todas;

  const termoNormalizado = normalizar(termo);
  return todas.filter((atividade) => normalizar(atividade.nome).includes(termoNormalizado));
}

export async function registrarAtividades(params: {
  userId: string;
  data: string;
  itens: ItemParaRegistrar[];
}): Promise<void> {
  const { userId, data, itens } = params;
  if (itens.length === 0) return;

  const registroDiarioId = await obterOuCriarRegistroDiario(userId, data);
  const horarioRegistro = new Date().toTimeString().slice(0, 8);

  const linhas = itens.map((item) => ({
    registro_diario_id: registroDiarioId,
    tipo_atividade: item.nomeAtividade,
    duracao_minutos: item.duracaoMinutos,
    horario_registro: item.horarioRegistro ?? horarioRegistro,
  }));

  const { error } = await supabase.from('registros_atividade_fisica').insert(linhas);
  if (error) throw error;
  registrarEvento('atividade_registrada', undefined, { userId });
}

export function horarioAgora(): string {
  return new Date().toTimeString().slice(0, 8);
}

// ---------------------------------------------------------------------
// Lacuna semanal de atividade física — mesmo espírito da lacuna de
// nutriente (ver nutrienteService.ts): conta em quantos dos últimos 7
// dias o total de minutos registrados bateu a meta diária, e reporta
// como lacuna se ficou abaixo do mínimo de dias esperado na semana.
//
// A meta diária (alvo_min) vem do catálogo de missões (missoes_catalogo,
// tipo ATIVIDADE_MIN) em vez de fixa aqui — é a mesma referência que já
// usávamos pra avaliar a missão do dia (ver missaoService.ts), então não
// há dois números diferentes de "quanto é suficiente" flutuando no app.
export type LacunaAtividade = { diasComAtividade: number; minimoDias: number; alvoMinPorDia: number };

const MINIMO_DIAS_ATIVIDADE_NA_SEMANA = 4; // mais de metade da semana com a meta diária batida

async function buscarAlvoMinDiarioAtividade(): Promise<number | null> {
  const { data, error } = await supabase
    .from('missoes_catalogo')
    .select('criterio')
    .eq('tipo', 'ATIVIDADE_MIN')
    .maybeSingle();
  if (error || !data?.criterio?.alvo_min) return null;
  return data.criterio.alvo_min as number;
}

/**
 * Total de minutos de atividade do dia + meta diária, para o feedback ao registrar.
 * Nunca lança: sem internet (ou sem meta cadastrada) devolve null nos campos e o
 * feedback fala só do que acabou de ser registrado.
 */
export async function buscarContextoAtividadeHoje(
  userId: string,
  data: string
): Promise<{ totalHojeMin: number | null; alvoMin: number | null }> {
  try {
    const [alvoMin, { data: dia, error }] = await Promise.all([
      buscarAlvoMinDiarioAtividade(),
      supabase
        .from('registros_diarios')
        .select('registros_atividade_fisica ( duracao_minutos )')
        .eq('user_id', userId)
        .eq('data', data)
        .maybeSingle(),
    ]);
    if (error) return { totalHojeMin: null, alvoMin };
    const totalHojeMin = ((dia as any)?.registros_atividade_fisica ?? []).reduce(
      (soma: number, r: any) => soma + r.duracao_minutos,
      0
    );
    return { totalHojeMin, alvoMin };
  } catch {
    return { totalHojeMin: null, alvoMin: null };
  }
}

/** Conta em quantos dos últimos 7 dias o total de minutos de atividade bateu a meta diária. */
export async function diasComAtividadeSuficienteNaSemana(userId: string, alvoMinPorDia: number): Promise<number> {
  const hoje = new Date();
  const seteDiasAtras = new Date(hoje);
  seteDiasAtras.setDate(hoje.getDate() - 6);

  const { data, error } = await supabase
    .from('registros_diarios')
    .select('data, registros_atividade_fisica ( duracao_minutos )')
    .eq('user_id', userId)
    .gte('data', formatarDataISO(seteDiasAtras))
    .lte('data', formatarDataISO(hoje));

  if (error) throw error;

  let diasComAtividade = 0;
  for (const dia of data ?? []) {
    const totalMin = ((dia as any).registros_atividade_fisica ?? []).reduce(
      (soma: number, r: any) => soma + r.duracao_minutos,
      0
    );
    if (totalMin >= alvoMinPorDia) diasComAtividade += 1;
  }
  return diasComAtividade;
}

/** Retorna a lacuna de atividade da semana, ou null se não há meta cadastrada ou se está tudo em dia. */
export async function detectarLacunaAtividade(userId: string): Promise<LacunaAtividade | null> {
  const alvoMinPorDia = await buscarAlvoMinDiarioAtividade();
  if (!alvoMinPorDia) return null; // sem missão ATIVIDADE_MIN ativa no catálogo, não dá pra saber a meta

  const diasComAtividade = await diasComAtividadeSuficienteNaSemana(userId, alvoMinPorDia);
  if (diasComAtividade >= MINIMO_DIAS_ATIVIDADE_NA_SEMANA) return null;

  return { diasComAtividade, minimoDias: MINIMO_DIAS_ATIVIDADE_NA_SEMANA, alvoMinPorDia };
}